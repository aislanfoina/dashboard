<?php
if(!($issueData = _any('issue_date'))) {
	$issueData = date("d-m-Y");
} 
$dias_de_prazo_para_pagamento = (_any('expiration')?_any('expiration'):10);

$project = $dao['projects']->getProjectbyId($id_project)[0];
$company = $dao['companies']->getCompanybyId($project['id_customer'])[0];
$sender = $dao['companies']->getCompanybyId(1)[0];
$cnt = $dao['slips']->getCntSlipbyCustomer($project['id_customer'],$issueData)[0]['cnt']+1;

$valor = (_any('value')?_any('value'):$project['value']);//800;

$taxa_boleto = 9;

$contrato = $project['contract'];//"PS-a301/2014";
$id = $company['id'];//"2";
$razao = $company['name']." - ".($company['id_type']==4?"CPF ":"CNPJ ").$company['cpf_cnpj'];//"Fabio Colombini ME - CNPJ 59.544.908/0001-09";
$endereco = $company['address'].", ".$company['address_number']." - ".$company['address_complement'];//"Alameda dos Maracatins, 426 - cj 411";
$cidade = $company['city'];//"Sao Paulo";
$estado = $company['state'];//"SP";
$cep = $company['zip'];//"04089-000";

$nossonumero = $id.str_pad($cnt, 2, "0", STR_PAD_LEFT).date("m", strtotime($issueData)).date("y", strtotime($issueData));//"010714"; //cnt, mes, ano;

// $strSQL 		= "SELECT ID_CLIENTE, ID_CONTATO,ID_CONTRATO_DESC, DESCRICAO, DATA, VALOR_TOTAL, BAIXADO, FINALIZADO, NOTA_FISCAL, DATA_PAGTO FROM CONTRATOS WHERE ID=".$id_contrato;
// $objRS	= mysql_query($strSQL, $sig) or die(mysql_error());
// $row_objRS = mysql_fetch_assoc($objRS);
// $id_cliente	= $row_objRS['ID_CLIENTE'];
// $id_contato	= $row_objRS['ID_CONTATO'];
// $descricao	= $row_objRS['DESCRICAO'];
// $contratoDesc = $row_objRS['ID_CONTRATO_DESC'];
// $data		= $row_objRS['DATA'];
// $valor 		= str_replace(".", "",$row_objRS['VALOR_TOTAL']);
// $finalizado		= $row_objRS['FINALIZADO'];
// $baixado		= $row_objRS['BAIXADO'];
// $nota		= $row_objRS['NOTA_FISCAL'];
// $data_nota 	= $row_objRS['DATA_PAGTO'];

// $strSQL 		= "SELECT CNPJ, FANTASIA, RAZAO, ENDERECO, BAIRRO, CEP, CIDADE, ESTADO, TELEFONE, OBS, desc_valor, desc_porcento FROM CLIENTES WHERE ID=".$id_cliente;
// $objRS1	= mysql_query($strSQL, $sig) or die(mysql_error());
// $row_objRS1 = mysql_fetch_assoc($objRS1);
// $cnpj		= $row_objRS1['CNPJ'];
// $fantasia	= $row_objRS1['FANTASIA'];
// $razao		= $row_objRS1['RAZAO'];
// $endereco	= $row_objRS1['ENDERECO'];
// $cep		= $row_objRS1['CEP'];
// $cidade		= $row_objRS1['CIDADE'];
// $estado		= $row_objRS1['ESTADO'];
// $telefone	= $row_objRS1['TELEFONE'];
// $obs		= $row_objRS1['OBS'];

// +----------------------------------------------------------------------+
// | BoletoPhp - Vers�o Beta                                              |
// +----------------------------------------------------------------------+
// | Este arquivo est� dispon�vel sob a Licen�a GPL dispon�vel pela Web   |
// | em http://pt.wikipedia.org/wiki/GNU_General_Public_License           |
// | Voc� deve ter recebido uma c�pia da GNU Public License junto com     |
// | esse pacote; se n�o, escreva para:                                   |
// |                                                                      |
// | Free Software Foundation, Inc.                                       |
// | 59 Temple Place - Suite 330                                          |
// | Boston, MA 02111-1307, USA.                                          |
// +----------------------------------------------------------------------+

// +----------------------------------------------------------------------+
// | Originado do Projeto BBBoletoFree que tiveram colabora��es de Daniel |
// | William Schultz e Leandro Maniezo que por sua vez foi derivado do	  |
// | PHPBoleto de Jo�o Prado Maia e Pablo Martins F. Costa				        |
// | 														                                   			  |
// | Se vc quer colaborar, nos ajude a desenvolver p/ os demais bancos :-)|
// | Acesse o site do Projeto BoletoPhp: www.boletophp.com.br             |
// +----------------------------------------------------------------------+

// +--------------------------------------------------------------------------------------------------------+
// | Equipe Coordena��o Projeto BoletoPhp: <boletophp@boletophp.com.br>              		             				|
// | Desenvolvimento Boleto Banco do Brasil: Daniel William Schultz / Leandro Maniezo / Rog�rio Dias Pereira|
// +--------------------------------------------------------------------------------------------------------+


// ------------------------- DADOS DIN�MICOS DO SEU CLIENTE PARA A GERA��O DO BOLETO (FIXO OU VIA GET) -------------------- //
// Os valores abaixo podem ser colocados manualmente ou ajustados p/ formul�rio c/ POST, GET ou de BD (MySql,Postgre,etc)	//

// DADOS DO BOLETO PARA O SEU CLIENTE
// $dias_de_prazo_para_pagamento = 10;
// $taxa_boleto = 2.95;
$data_venc = date("d/m/Y", strtotime($issueData) + ($dias_de_prazo_para_pagamento * 86400));  // Prazo de X dias OU informe data: "13/04/2006"; 
$valor_cobrado = $valor; // Valor - REGRA: Sem pontos na milhar e tanto faz com "." ou "," ou com 1 ou 2 ou sem casa decimal
$valor_cobrado = str_replace(",", ".",$valor_cobrado);
$valor_boleto=number_format($valor_cobrado+$taxa_boleto, 2, ',', '');

$dadosboleto["nosso_numero_raw"] = $nossonumero;
$dadosboleto["nosso_numero"] = $nossonumero;
$dadosboleto["numero_documento"] = $contrato;	// Num do pedido ou do documento
$dadosboleto["data_vencimento"] = $data_venc; // Data de Vencimento do Boleto - REGRA: Formato DD/MM/AAAA
$dadosboleto["data_documento"] = date("d/m/Y", strtotime($issueData)); // Data de emiss�o do Boleto
$dadosboleto["data_processamento"] = date("d/m/Y", strtotime($issueData)); // Data de processamento do boleto (opcional)
$dadosboleto["valor_boleto"] = $valor_boleto; 	// Valor do Boleto - REGRA: Com v�rgula e sempre com duas casas depois da virgula

// DADOS DO SEU CLIENTE
$dadosboleto["sacado"] = $razao;
$dadosboleto["endereco1"] = $endereco;
$dadosboleto["endereco2"] = "$cidade - $estado -  CEP: $cep";

// INFORMACOES PARA O CLIENTE
$dadosboleto["demonstrativo1"] = (_any('description')?_any('description'):"Pagamento contrato $contrato do ".($project['id_contract']==2?"mês ".date("m/y", strtotime($issueData)):"ano ".date("Y", strtotime($issueData))));
$dadosboleto["demonstrativo2"] = "Taxa boleto - R$ $taxa_boleto,00";
// $dadosboleto["demonstrativo1"] = "Pagamento de Contrato de Suporte $contrato com a Foitec LTDA";
// $dadosboleto["demonstrativo2"] = "Descri��o: Contrato de Suporte T�cnico mensal";
$dadosboleto["demonstrativo3"] = "&nbsp;";

// INSTRU��ES PARA O CAIXA
$dadosboleto["instrucoes1"] = "";//- Sr. Caixa, cobrar multa de 2% ap�s o vencimento";
$dadosboleto["instrucoes2"] = "- Não receber após o vencimento";
$dadosboleto["instrucoes3"] = "- Em caso de dúvidas entre em contato conosco: financeiro@foi.tech";
$dadosboleto["instrucoes4"] = "&nbsp;";

// DADOS OPCIONAIS DE ACORDO COM O BANCO OU CLIENTE
$dadosboleto["quantidade"] = "";
$dadosboleto["valor_unitario"] = "";
$dadosboleto["aceite"] = "N";		
$dadosboleto["especie"] = "R$";
$dadosboleto["especie_doc"] = "DM";


// ---------------------- DADOS FIXOS DE CONFIGURA��O DO SEU BOLETO --------------- //


// DADOS DA SUA CONTA - BANCO DO BRASIL
$dadosboleto["agencia"] = "3559"; // Num da agencia, sem digito
$dadosboleto["conta"] = "47747"; 	// Num da conta, sem digito

// DADOS PERSONALIZADOS - BANCO DO BRASIL
$dadosboleto["convenio"] = "2553527";  // Num do conv�nio - REGRA: 6 ou 7 ou 8 d�gitos
$dadosboleto["contrato"] = "19059981"; // Num do seu contrato
$dadosboleto["carteira"] = "18";
$dadosboleto["variacao_carteira"] = "-019";  // Varia��o da Carteira, com tra�o (opcional)

// TIPO DO BOLETO
$dadosboleto["formatacao_convenio"] = "7"; // REGRA: 8 p/ Conv�nio c/ 8 d�gitos, 7 p/ Conv�nio c/ 7 d�gitos, ou 6 se Conv�nio c/ 6 d�gitos
$dadosboleto["formatacao_nosso_numero"] = "2"; // REGRA: Usado apenas p/ Conv�nio c/ 6 d�gitos: informe 1 se for NossoN�mero de at� 5 d�gitos ou 2 para op��o de at� 17 d�gitos

/*
#################################################
DESENVOLVIDO PARA CARTEIRA 18

- Carteira 18 com Convenio de 8 digitos
  Nosso n�mero: pode ser at� 9 d�gitos

- Carteira 18 com Convenio de 7 digitos
  Nosso n�mero: pode ser at� 10 d�gitos

- Carteira 18 com Convenio de 6 digitos
  Nosso n�mero:
  de 1 a 99999 para op��o de at� 5 d�gitos
  de 1 a 99999999999999999 para op��o de at� 17 d�gitos

#################################################
*/


// SEUS DADOS
$dadosboleto["identificacao"] = $sender['name'];//"FOITEC TECNOLOGIA DA INFORMA��O LTDA";
$dadosboleto["cpf_cnpj"] = $sender['cpf_cnpj'];//"17.879.204/0001-47";
$dadosboleto["endereco"] = $sender['address'];//"SHCN CL QD 205 BL A LJ 18";
$dadosboleto["cidade_uf"] = $sender['city']." / ".$sender['state'];//"Brasilia / DF";
$dadosboleto["cedente"] = $sender['name'];//"FOITEC TECNOLOGIA DA INFORMA��O LTDA";
?>