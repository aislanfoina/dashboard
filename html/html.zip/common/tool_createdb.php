// <?php
// // Padrao DB
// // Campos em ingles
// // Plural quando representa diversas (nome de tabela)
// // Singluar quando eh um unitario (relacao N x N)

// /*  Projetos possuem relacao NxN com:
//  *  - id_note, id_customer, id_partner, id_member, id_task
//  *  
//  *  Tarefas tem NxN com:
//  *  - id_dependecy, id_responsable
//  */

// // fix: alter table users modify cellphone varchar(15);
// // alter table companies modify phone varchar(15);

// //fix2: 
// // alter table rel_proj_note add column `id_owner` int(6) unsigned NOT NULL;
// // alter table rel_proj_note add column `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP;
// /*
// rel_proj_note
// rel_proj_cust
// rel_proj_part
// rel_proj_memb
// rel_proj_task
// rel_task_depe
// rel_task_resp
// */
// $sql_create = "CREATE TABLE `portfolio` (
//   `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
//   `id_category` int(6) NOT NULL DEFAULT '0',
//   `filename` varchar(100) NOT NULL DEFAULT '',
//   `title` varchar(255) NOT NULL DEFAULT '',
//   `description` text DEFAULT '',
//   `id_status` int(3) unsigned NOT NULL DEFAULT 1,
//   `id_owner` int(6) unsigned NOT NULL,
//   `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
//   PRIMARY KEY (`id`),
//   KEY `id` (`id`)
// ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
// if(!mysql_num_rows( mysql_query("SHOW TABLES LIKE 'portfolio'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// }

// $sql_create = "CREATE TABLE `categories` (
//   `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
//   `id_parent` int(6) unsigned DEFAULT '0',
//   `id_portfolio` int(6) unsigned DEFAULT '0',
//   `category` varchar(100) NOT NULL DEFAULT '',
//   `title` varchar(100) NOT NULL DEFAULT '',
//   `description` text DEFAULT '',
//   `id_status` int(3) unsigned NOT NULL DEFAULT 1,
//   `id_owner` int(6) unsigned NOT NULL,
//   `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
//   PRIMARY KEY (`id`),
//   KEY `id` (`id`)
// ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
// if(!mysql_num_rows( mysql_query("SHOW TABLES LIKE 'categories'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// }

// $sql_create = "CREATE TABLE `users` (
// `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
// `email` varchar(100) NOT NULL,
// `password` varchar(50) NOT NULL,
// `password_expired` int(1) NOT NULL DEFAULT 1,
// `name` varchar(200) NOT NULL,
// `cellphone` varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci,
// `sex` varchar(15) CHARACTER SET latin1 COLLATE latin1_spanish_ci,
// `birthday` date,
// `address` text DEFAULT '',
// `id_extra` int(6) unsigned DEFAULT 0,		
// `id_job` int(3) unsigned NOT NULL default 0,
// `id_boss` int(6) unsigned DEFAULT 0,		
// `id_color` int(3) unsigned DEFAULT 0,
// `id_status` int(3) unsigned DEFAULT 0,
// `id_role` int(6) unsigned DEFAULT 0,
// `id_owner` int(6) unsigned NOT NULL,
// `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
// PRIMARY KEY (`id`),
// KEY `id` (`id`)
// ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
// if(!mysql_num_rows( mysql_query("SHOW TABLES LIKE 'users'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// 	$sql_insert = "INSERT INTO users (username,password,fullname,email,id_role,id_owner) values ('root','globalsys123','Root','root@gtptecnologia.com',1,0)";
// }
// $sql_create = "CREATE TABLE `config` (
// `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
// `field` varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
// `value` varchar(255) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
// `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT '',
// PRIMARY KEY (`id`),
// KEY `id` (`id`)
// )";
// if(!mysql_num_rows( mysql_query("SHOW TABLES LIKE 'config'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value,description) values ('max_upload_member_total','20','Max number of images sent to the portfolio by a member user')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value,description) values ('max_upload_member_category','5','Max number of images sent to one portfolio category by a member user')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value,description) values ('max_upload_total','10','Max number of images sent to the portfolio by a regular user')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value,description) values ('max_upload_category','3','Max number of images sent to one portfolio category by a regular user')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value) values ('max_upload_dim','1200')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value) values ('photo_path','/var/www/afnatura/arquivos/concursos/')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value) values ('photo_url','./arquivos/concursos/')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value) values ('km_carro','0.50')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO config (field,value) values ('km_moto','0.15')";
// 	mysql_query($sql_insert) or die(mysql_error());
// }

// $sql_create = "CREATE TABLE `job` (
// `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
// `area` varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
// `job` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
// PRIMARY KEY (`id`),
// KEY `id` (`id`)
// )";
// if(!mysql_num_rows( mysql_query("SHOW TABLES LIKE 'job'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('N�o definido','N�o definido')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('T�cnico','Diretor T�cnico')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Comercial','Diretor Comercial')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Administrativo','Diretor Administrativo')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('T�cnico','Gerente T�cnico')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Comercial','Gerente Comercial')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Administrativo','Gerente Administrativo')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('T�cnico','Engenheiro')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Administrativo','Marketing')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Administrativo','Financeiro')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('T�cnico','Analista')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Comercial','Comercial')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Administrativo','Auxiliar Administrativo')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('T�cnico','Estagi�rio T�cnico')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Comercial','Estagi�rio Comercial')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('Administrativo','Estagi�rio Administrativo')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO job (area,job) values ('N�o definido','Outro')";
// 	mysql_query($sql_insert) or die(mysql_error());
// }

// $sql_create = "CREATE TABLE `role` (
// `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
// `role` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
// `id_status` int(3) unsigned DEFAULT 0,
// `Regras` int(3) DEFAULT 0,
// PRIMARY KEY (`id`),
// KEY `id` (`id`)
// )";
// if(!mysql_num_rows( mysql_query("SHOW TABLES LIKE 'role'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// 	$sql_insert = "INSERT INTO role (role,id_status,Regras) values ('Admin',1,1)";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO role (role,id_status,Regras) values ('Viewer',1,-1)";
// 	mysql_query($sql_insert) or die(mysql_error());
// }

// $sql_create = "CREATE TABLE `status` (
// `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
// `status` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
// PRIMARY KEY (`id`),
// KEY `id` (`id`)
// )";
// if(!mysql_num_rows( mysql_query("SHOW TABLES LIKE 'status'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// 	$sql_insert = "INSERT INTO status (status) values ('Ativo')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO status (status) values ('Cancelado')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO status (status) values ('Em andamento')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO status (status) values ('Paralizado')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO status (status) values ('Concluido')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO status (status) values ('Participante')";
// 	mysql_query($sql_insert) or die(mysql_error());
// 	$sql_insert = "INSERT INTO status (status) values ('Finalista')";
// 	mysql_query($sql_insert) or die(mysql_error());
// }

// $sql_create = "
// DELIMITER $$
// CREATE FUNCTION  `regex_replace`(pattern VARCHAR(1000),replacement VARCHAR(1000),original VARCHAR(1000))

// RETURNS VARCHAR(1000)
// DETERMINISTIC
// BEGIN 
//  DECLARE temp VARCHAR(1000); 
//  DECLARE ch VARCHAR(1); 
//  DECLARE i INT;
//  SET i = 1;
//  SET temp = '';
//  IF original REGEXP pattern THEN 
//   loop_label: LOOP 
//    IF i>CHAR_LENGTH(original) THEN
//     LEAVE loop_label;  
//    END IF;
//    SET ch = SUBSTRING(original,i,1);
//    IF NOT ch REGEXP pattern THEN
//     SET temp = CONCAT(temp,ch);
//    ELSE
//     SET temp = CONCAT(temp,replacement);
//    END IF;
//    SET i=i+1;
//   END LOOP;
//  ELSE
//   SET temp = original;
//  END IF;
//  RETURN temp;
// END$$
// DELIMITER ;		
// ";
// if(!mysql_num_rows( mysql_query("SHOW FUNCTION STATUS WHERE Name LIKE 'regex_replace'")))
// {
// 	mysql_query($sql_create) or die(mysql_error());
// }