<?php

// Mostra todas as informaçs, usa o padrãINFO_ALL
phpinfo();

// Mostra apenas informaçs dos móos.
// phpinfo(8) mostra um resultado identico.
phpinfo(INFO_MODULES);

?>
