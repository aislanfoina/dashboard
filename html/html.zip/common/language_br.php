<?php
define("INDEX_NOVIDADES","Novidades");
define("INDEX_PESQUISA_TEMAS","Pesquisa por Temas");
define("TITLE_AGENCIA","Ag�ncia");
define("MESA_LUZ","Mesa de Luz");
define("","");

?>