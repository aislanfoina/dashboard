<?php
define("INDEX_NOVIDADES","News");
define("INDEX_PESQUISA_TEMAS","Search by subject");
define("TITLE_AGENCIA","Agency");
define("MESA_LUZ","Lightbox");
define("","");

?>