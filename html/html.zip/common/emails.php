<?php
function sendPasswordEmail($user) {
	$from = "Contato Afnatura <afnatura@afnatura.org.br>";
	$to = $user['email'];
	$subject = "Recuperar Senha - Concurso AFNatura";

	$m =  '
<table>
	<tr>
    	<th>Caro/a '.$user['name'].',</th>
    </tr>
	<tr>
    	<td>Foi feita uma solicitação pelo site AFNatura para envio da sua senha para seu email. Se essa solicitação não foi feita por você, por favor desconsidere esse email. </td>
    </tr>
    <tr>
    	<td>Sua senha é '.$user['password'].'</td>
    </tr>
     <tr>
    	<td>Obrigado!</td>
    </tr>
</table>';

	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";

	mail ($to,$subject,$m,$headers) ;
}

function sendSubscribeEmail($user) {
	$from = "Contato Afnatura <afnatura@afnatura.org.br>";
	$to = $user['email'];
	$subject = "Inscrição no Concurso AFNatura feita com sucesso!";

	$m =  '
<table>
	<tr>
    	<th>Caro/a '.$user['name'].',</th>
    </tr>
	<tr>
    	<td>A AFNatura confirma seu cadastro no concurso. Seu número de identificação é '.$user['id'].'.</td>
    </tr>
     <tr>
    	<td>Obrigado!</td>
    </tr>
</table>';

	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";

	mail ($to,$subject,$m,$headers) ;
}

function sendBirthdayEmail($usuario) {
	$from = "Contato Afnatura <afnatura@afnatura.org.br>";
	$to = $usuario['login'];
	$subject = "Feliz Aniversário!";
	
	$m =  '
<table>
	<tr>
    	<th>'.$usuario['nome'].', parabéns pelo seu aniversário!</th>
    </tr>
</table>';
	
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";
	
	mail ($to,$subject,$m,$headers) ;
}

function sendExpiredEmail($usuario) {
	$from = "Fianceiro Afnatura <afnatura@afnatura.org.br>";
	$to = $usuario['login'];
	$subject = "Anuidade AFNatura vencida!";
	
	$m =  '
<table>
	<tr>
    	<th>Caro/a '.$usuario['nome'].',</th>
    </tr>
	<tr>
    	<td>Lembramos que sua anuidade está vencida. A AFNATURA desenvolve suas atividades com base na anuidade dos associados e no trabalho voluntário da diretoria.</td>
    </tr>
</table>';
	
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";
	
	mail ($to,$subject,$m,$headers) ;
}

function sendExpiringEmail($usuario) {
	$from = "Fianceiro Afnatura <afnatura@afnatura.org.br>";
	$to = $usuario['login'];
	$subject = "Anuidade AFNatura vai vencer!";
	
	$m =  '
<table>
	<tr>
    	<th>Caro/a '.$usuario['nome'].',</th>
    </tr>
	<tr>
    	<td>Sua anuidade vai vencer daqui a 30 dias. Pedimos sua atenção, pois a associação se mantém com o apoio dos associados, com trabalhos voluntários e com os recursos das anuidades.</td>
    </tr>
</table>';
	
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";
	
	mail ($to,$subject,$m,$headers) ;
}

function sendRenewEmail($usuario) {
	$from = "Fianceiro Afnatura <afnatura@afnatura.org.br>";
	$to = $usuario['login'];
	$subject = "Anuidade AFNatura renovada!";

	$m =  '
<table>
	<tr>
    	<th>Obrigado, '.$usuario['nome'].'. Sua anuidade está quitada por mais um ano.</th>
    </tr>
</table>';

	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";

	mail ($to,$subject,$m,$headers) ;
}

function sendWelcomeEmail($usuario) {
	$from = "Contato Afnatura <afnatura@afnatura.org.br>";
	$to = $usuario['login'];
	$subject = "Bem vindo à AFNATURA!";

	$m =  '
<table>
	<tr>
    	<th>Bem vindo à AFNATURA, '.$usuario['nome'].'.</th>
    </tr>
	<tr>
		<td>Você agora faz parte da associação que reúne os fotógrafos de natureza do Brasil, profissionais e amantes da fotografia de natureza e do meio ambiente. Aqui você receberá informações para aprimorar sua fotografia e sobre locais interessantes para fotografar em nosso país.</td>
	</tr>
</table>';

	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";

	mail ($to,$subject,$m,$headers) ;
}

function sendConcurso2015Email($usuario) {
	$from = "Contato Afnatura <afnatura@afnatura.org.br>";
	$to = $usuario['login'];
	$subject = "Concurso AFNATURA!";

	$m =  '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<p style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black">Caro associado,</span>
<span style="font-family:Arial,sans-serif;color:black"><u></u><u></u></span>
</p>
<p style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black"><u></u>&nbsp;<u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black">A AFNATURA está promovendo o "1º Concurso de Fotografia de Natureza do Brasil", aberto a todos os residentes no país.</span><span style="font-family:Arial,sans-serif;color:black"><u></u><u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black"><u></u>&nbsp;<u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black">Participe!<u></u><u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black">Você estará fortalecendo a fotografia de natureza brasileira, terá chance de receber prêmios em dinheiro, além de ter sua foto publicada na revista Fotografe Melhor, em&nbsp;reportagem&nbsp;exclusiva.&nbsp;</span><span style="font-family:Arial,sans-serif"><u></u><u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black"><u></u>&nbsp;<u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black">Veja os detalhes no link <a href="http://www.afnatura.org.br/concursos">http://www.afnatura.org.br/concursos</a><u></u><u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black"><u></u>&nbsp;<u></u></span></p>
<p class="MsoNormal" style="margin:0cm 0cm 0.0001pt;font-size:12pt;font-family:\'Times New Roman\',serif;color:rgb(34,34,34)"><span style="font-family:Arial,sans-serif;color:black">&nbsp;
<img src="http://www.afnatura.org.br/imgs/Concurso2015.jpg"/>
</span></p>
</body>			
';

	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=utf-8\r\n";
	$headers .= "From: $from\n";
	$headers .= "To: <$to>\n";

	mail ($to,$subject,$m,$headers) ;
}

function simple_hunterMailTaskCancel($gtp, $id_task) {
	$text_subject = "Tarefa Cancelada";
	$text_body = "<p>A tarefa abaixo foi cancelada: <p>";
	simple_hunterMailTaskAction($gtp, $id_task, $text_subject, $text_body);
}

function simple_hunterMailTaskDone($gtp, $id_task) {
	$text_subject = "Tarefa Concluída";
	$text_body = "<p>A tarefa abaixo foi concluída: <p>";
	simple_hunterMailTaskAction($gtp, $id_task, $text_subject, $text_body);
}

function simple_hunterMailTaskAction($gtp, $id_task, $text_subject, $text_body) {
	include("constants.php");

	$query_add_field = "";
	$query_add_join = "";
	$query_add_where = "";
	if($id_task) {
		$query_add_where = " tasks.id = $id_task ";
	}

	$query_single_task = "SELECT tasks.id, tasks.name, tasks.description, tasks.id_status, status.status, tasks.id_priority, priority.priority, tasks.deadline, tasks.id_deadline_action, deadline_action.deadline_action, rel.responsables, rel2.projects $query_add_field FROM tasks
	LEFT JOIN (SELECT rel_task_resp.id_task, group_concat(users.fullname) AS responsables FROM rel_task_resp LEFT JOIN users ON users.id = rel_task_resp.id_responsable GROUP BY rel_task_resp.id_task) AS rel ON tasks.id = rel.id_task
	LEFT JOIN (SELECT rel_proj_task.id_task, group_concat(projects.name) AS projects FROM rel_proj_task LEFT JOIN projects ON projects.id = rel_proj_task.id_project GROUP BY rel_proj_task.id_task) AS rel2 ON tasks.id = rel2.id_task
	LEFT JOIN status ON tasks.id_status = status.id
	LEFT JOIN priority ON tasks.id_priority = priority.id
	LEFT JOIN deadline_action ON tasks.id_deadline_action = deadline_action.id
	$query_add_join
	WHERE $query_add_where ORDER BY name ASC";
	$single_task = mysql_query($query_single_task, $gtp) or die(mysql_error());
	$row_single_task = mysql_fetch_assoc($single_task);

	$query_projects_members_task = "SELECT rel_proj_memb.id_member AS id_user, users.email FROM rel_proj_memb
	LEFT JOIN users ON users.id = rel_proj_memb.id_member
	LEFT JOIN projects ON rel_proj_memb.id_project = projects.id
	LEFT JOIN rel_proj_task ON rel_proj_task.id_project = projects.id
	WHERE rel_proj_task.id_task = $id_task
	UNION
	SELECT rel_task_resp.id_responsable AS id_user, users.email FROM rel_task_resp
	LEFT JOIN users ON users.id = rel_task_resp.id_responsable
	WHERE rel_task_resp.id_task = $id_task";
	$projects_members_task = mysql_query($query_projects_members_task, $gtp) or die(mysql_error());
	$row_projects_members_task = mysql_fetch_assoc($projects_members_task);

	$email = $row_projects_members_task['email'];
	while($row_projects_members_task = mysql_fetch_assoc($projects_members_task)) {
		$email .= ",".$row_projects_members_task['email'];
	}

	$link = $hunter_url."tasks.php?save_task=true&action=carregar&id=".$row_single_task['id']."&id_task=".$row_single_task['id'];
	$name = $row_single_task['name'];
	$project = $row_single_task['projects'];
	$resposable = $row_single_task['responsables'];
	$status = $row_single_task['status'];
	$priority = $row_single_task['priority'];
	if($row_single_task['deadline'] != "0000-00-00") {
		$date = new DateTime($row_single_task['deadline']);
		$deadline = $date->format('d/m/Y');
		$diff = $date->diff(new DateTime());
		if($diff->format('%R%a') > 0)
			$deadline_days = "Vencido!";
		else
			$deadline_days = $diff->format('%a');
	}
	else {
		$deadline = "";
		$deadline_days = "-";
	}
	$description = $row_single_task['description'];
	$deadline_action = $row_single_task['deadline_action'];

	$subject = "$text_subject - $name";
	$body = $text_body;
	$body .= "
	<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
	<thead>
	<tr>
	<td colspan=\"6\">Tarefa</td>
	</tr>
	<tr>
	<td>Nome</td>
	<td>Projeto</td>
	<td>Responsáveis</td>
	<td>Status</td>
	<td>Prioridade</td>
	<td>Deadline (dias)</td>
	</tr>
	</thead>
	<tbody>
	<tr>
	<td><a href=\"$link\">$name</a></td>
	<td>$project</td>
	<td>$resposable</td>
	<td>$status</td>
	<td>$priority</td>
	<td>$deadline ($deadline_days)</td>
	</tr>
	</tbody>
	</table>

	<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
	<thead>
	<tr>
	<td>Descrição</td>
	<td>Ação no Vencimento</td>
	</tr>
	</thead>
	<tbody>
	<tr>
	<td>$description</td>
	<td>$deadline_action</td>
	</tr>
	</tbody>
	</table>";

	// 	echo $body;
	// 	echo "<br>**<br>$email";
	return hunterMail($email, $subject, $body);
}

function simple_hunterMailTask($gtp, $id_user, $id_task) {
	include("constants.php");

	$query_add_field = "";
	$query_add_join = "";
	$query_add_where = "";
	if($id_task) {
		$query_add_where = " AND tasks.id = $id_task ";
	}

	$query_single_task = "SELECT tasks.id, tasks.name, tasks.description, tasks.id_status, status.status, tasks.id_priority, priority.priority, tasks.deadline, tasks.id_deadline_action, deadline_action.deadline_action, rel.responsables, rel2.projects $query_add_field FROM tasks
	LEFT JOIN (SELECT rel_task_resp.id_task, group_concat(users.fullname) AS responsables FROM rel_task_resp LEFT JOIN users ON users.id = rel_task_resp.id_responsable GROUP BY rel_task_resp.id_task) AS rel ON tasks.id = rel.id_task
	LEFT JOIN (SELECT rel_proj_task.id_task, group_concat(projects.name) AS projects FROM rel_proj_task LEFT JOIN projects ON projects.id = rel_proj_task.id_project GROUP BY rel_proj_task.id_task) AS rel2 ON tasks.id = rel2.id_task
	LEFT JOIN status ON tasks.id_status = status.id
	LEFT JOIN priority ON tasks.id_priority = priority.id
	LEFT JOIN deadline_action ON tasks.id_deadline_action = deadline_action.id
	$query_add_join
	WHERE tasks.id_status != $cons_t_delstatus $query_add_where ORDER BY name ASC";
	$single_task = mysql_query($query_single_task, $gtp) or die(mysql_error());
	$row_single_task = mysql_fetch_assoc($single_task);

	$link = $hunter_url."tasks.php?save_task=true&action=carregar&id=".$row_single_task['id']."&id_task=".$row_single_task['id'];
	$name = $row_single_task['name'];
	$project = $row_single_task['projects'];
	$resposable = $row_single_task['responsables'];
	$status = $row_single_task['status'];
	$priority = $row_single_task['priority'];
	if($row_single_task['deadline'] != "0000-00-00") {
		$date = new DateTime($row_single_task['deadline']);
		$deadline = $date->format('d/m/Y');
		$diff = $date->diff(new DateTime());
		if($diff->format('%R%a') > 0)
			$deadline_days = "Vencido!";
		else
			$deadline_days = $diff->format('%a');
	}
	else {
		$deadline = "";
		$deadline_days = "-";
	}
	$description = $row_single_task['description'];
	$deadline_action = $row_single_task['deadline_action'];

	$subject = "Nova Tarefa - $name";
	$body = "<p>Você foi incluído na tarefa abaixo: <p>";
	$body .= "
	<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
	<thead>
	<tr>
	<td colspan=\"6\">Tarefa</td>
	</tr>
	<tr>
	<td>Nome</td>
	<td>Projeto</td>
	<td>Responsáveis</td>
	<td>Status</td>
	<td>Prioridade</td>
	<td>Deadline (dias)</td>
	</tr>
	</thead>
	<tbody>
	<tr>
	<td><a href=\"$link\">$name</a></td>
	<td>$project</td>
	<td>$resposable</td>
	<td>$status</td>
	<td>$priority</td>
	<td>$deadline ($deadline_days)</td>
	</tr>
	</tbody>
	</table>

	<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
	<thead>
	<tr>
	<td>Descrição</td>
	<td>Ação no Vencimento</td>
	</tr>
	</thead>
	<tbody>
	<tr>
	<td>$description</td>
	<td>$deadline_action</td>
	</tr>
	</tbody>
	</table>";

	// 	$query_load = "SELECT * FROM users WHERE id = $id_user";
	// 	$load = mysql_query($query_load, $gtp) or die(mysql_error());
	// 	$row_load = mysql_fetch_array($load);
	// 	$email = $row_load['email'];

	return simple_hunterMail($id_user, $subject, $body, $gtp);

}
function simple_hunterMail($id_user, $subject, $body, $gtp) {
	$query_load = "SELECT * FROM users WHERE id = $id_user";
	$load = mysql_query($query_load, $gtp) or die(mysql_error());
	$row_load = mysql_fetch_array($load);
	$email = $row_load['email'];
	return hunterMail($email, $subject, $body);
}

function hunterMail($emails, $subject, $body, $file = NULL, $fileContent = NULL) {
	$mail = new PHPMailer();

	$mail->IsSMTP();
	$mail->SMTPDebug = 1;                                      // set mailer to use SMTP
	$mail->Host = "smtp.gmail.com";  // specify main and backup server
	//	$mail->Host = "mail.email.alog.com.br";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->SMTPSecure = "ssl";
	$mail->Port = 465;
	$mail->Username = "hunter.gtp@gmail.com";  // SMTP username
	$mail->Password = "globalsys123"; // SMTP password
	//	$mail->Username = "hunter@gtptecnologia.com";  // SMTP username
	//	$mail->Password = "123qwe!!"; // SMTP password

	//	$mail->From = "hunter@gtptecnologia.com";
	$mail->From = "hunter.gtp@gmail.com";
	$mail->FromName = "Hunter Intranet";
	$emails_arr = explode(",",$emails);
	foreach ($emails_arr as $email)
		$mail->AddAddress(trim($email));
	$mail->AddReplyTo("aislan@gtptecnologia.com", "Aislan");

	//$mail->WordWrap = 50;                                 // set word wrap to 50 characters
	if($file != NULL && $fileContent != NULL)
		$mail->AddStringAttachment($fileContent, $file);         // add attachments
	//$mail->AddAttachment("/tmp/image.jpg", "new.jpg");    // optional name
	$mail->IsHTML(true);                                  // set email format to HTML

	$mail->Subject = $subject;
	$mail->Body    = $body;
	//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

	if(!$mail->Send())
	{
		return "Message could not be sent. <p>";
		//echo "Mailer Error: " . $mail->ErrorInfo;
		//	exit;
	}

	return "Message has been sent";
}

function amazonMail($from, $fromName, $email, $subject, $body) {
	$mail = new PHPMailer();

	$mail->CharSet = 'UTF-8';
	
	$mail->IsSMTP();
	$mail->SMTPDebug = 1;                                      // set mailer to use SMTP
	$mail->Host = "email-smtp.us-east-1.amazonaws.com";  // specify main and backup server
	//	$mail->Host = "mail.email.alog.com.br";  // specify main and backup server
	$mail->SMTPAuth = true;     // turn on SMTP authentication
	$mail->SMTPSecure = "tls";
	$mail->Port = 587;
	$mail->Username = "AKIAIJV7UGYSONSEP7XA";  // SMTP username
	$mail->Password = "ArZ1GyOAOXghGhYu+zIpse3ZO+1o1YOVSyCmhMSGbTeo"; // SMTP password
	//	$mail->Username = "hunter@gtptecnologia.com";  // SMTP username
	//	$mail->Password = "123qwe!!"; // SMTP password

	//	$mail->From = "hunter@gtptecnologia.com";
	$mail->From = $from;
	$mail->FromName = $fromName;
	$mail->AddAddress($email);

	//$mail->WordWrap = 50;                                 // set word wrap to 50 characters
	//$mail->AddAttachment("/var/tmp/file.tar.gz");         // add attachments
	//$mail->AddAttachment("/tmp/image.jpg", "new.jpg");    // optional name
	$mail->IsHTML(true);                                  // set email format to HTML

	$mail->Subject = $subject;
	$mail->Body    = $body;
	//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

	if(!$mail->Send())
	{
		echo "Message could not be sent. <p>";
		//	echo "Mailer Error: " . $mail->ErrorInfo;
		//	exit;
	}

	//	echo "Message has been sent";
}
