<?php
header("location: ./en/index.php");
?>