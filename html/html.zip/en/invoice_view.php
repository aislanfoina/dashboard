<?php require("../common/config.php")?>
<?php 
$number = (_any('number')?_any('number'):'SRV-1601001A-00');
$invoice = $dao['invoices']->getInvoicebyNumber($number);
$items = $dao['invoiceitems']->getItemsbyIdInvoice($invoice['id']);
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?></head>
<body>
    <div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-6">
                    <h2>Invoice</h2>
                </div>
                <div class="col-lg-6">
                    <div class="title-action">
                        <a href="invoice_print.php?number=<?php echo $invoice['number']?>" target="_blank" class="btn btn-primary"><i class="fa fa-print"></i> Print </a>
                    </div>
                </div>
            </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInRight">
                    <div class="ibox-content p-xl">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h4>Project: </h4>
                                    <h4 class="text-navy" id="update|select|invoices|id_project|<?php echo $invoice['id']?>||projects|name| | |<?php echo $invoice['project_id']?>"><?php echo $invoice['project_name']?></h4>
                                    <h5>From:</h5>
                                    <address>
                                        <strong class="" id="update|select|invoices|id_issuer|<?php echo $invoice['id']?>||companies|name|id_type|1|<?php echo $invoice['issuer_id']?>"><?php echo $invoice['issuer_name']?></strong><br>
                                        <?php echo $invoice['issuer_address_number']?> <?php echo $invoice['issuer_address']?><?php echo ($invoice['issuer_address_complement']!=""?", ".$invoice['issuer_address_complement']:"")?><br>
                                        <?php echo $invoice['issuer_city']?>, <?php echo $invoice['issuer_state']?> <?php echo $invoice['issuer_zip']?><br>
                                        <abbr title="Phone">P:</abbr> <?php echo $invoice['issuer_phone']?>
                                    </address>
                                </div>

                                <div class="col-sm-6 text-right">
                                    <h4>Invoice No.</h4>
                                    <h4 class="text-navy" id="update|text|invoices|number|<?php echo $invoice['id']?>"><?php echo $invoice['number']?></h4>
                                    <span>To:</span>
                                    <address>
                                        <strong class="" id="update|select|invoices|id_customer|<?php echo $invoice['id']?>||companies|name|id_type|2,3,4|<?php echo $invoice['cust_id']?>"><?php echo $invoice['cust_name']?></strong><br>
                                        <?php echo $invoice['cust_address_number']?> <?php echo $invoice['cust_address']?><?php echo ($invoice['cust_address_complement']!=""?", ".$invoice['cust_address_complement']:"")?><br>
                                        <?php echo $invoice['cust_city']?>, <?php echo $invoice['cust_state']?> <?php echo $invoice['cust_zip']?><br>
                                        <abbr title="Phone">P:</abbr> <?php echo $invoice['cust_phone']?>
                                    </address>
                                    <p>
                                        <span><strong>Invoice Date:</strong> <span class="" id="update|date|invoices|issue_date|<?php echo $invoice['id']?>"><?php echo date("m-d-y", strtotime($invoice['issue_date']))?></span></span><br/>
                                        <span><strong>Due Date:</strong> <span class="" id="update|date|invoices|due_date|<?php echo $invoice['id']?>"><?php echo date("m-d-y", strtotime($invoice['due_date']))?></span></span>
                                    </p>
                                </div>
                            </div>

                            <div class="table-responsive m-t">
                                <table class="table invoice-table">
                                    <thead>
                                    <tr>
                                        <th>Item List</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Tax</th>
                                        <th>Total Price</th>
                                    </tr>
                                    </thead>
                                    <tbody>
<?php 
	$totalSub = 0;
	$totalTax = 0;
	$totalGran = 0;
	foreach ($items as $item) { 
		$qty = $item['quantity'];
		$value = $item['value'];
		$tax = $item['tax'];
		$total = $qty*($value+$tax);
		$totalSub += $qty*$value;
		$totalTax += $qty*$tax;
		$totalGran += $total;
?>                                    
                                    <tr>
                                        <td><div><strong class="" id="update|select|invoiceitems|id_product|<?php echo $item['id']?>||products|description| | |<?php echo $item['id']?>"><?php echo $item['description']?></strong></div>
                                            <small class="" id="update|text|invoiceitems|obs|<?php echo $item['id']?>"><?php echo $item['obs']?></small></td>
                                        <td class="" id="update|text|invoiceitems|quantity|<?php echo $item['id']?>"><?php echo $qty?></td>
                                        <td class="" id="update|money|invoiceitems|value|<?php echo $item['id']?>">$<?php echo formatnumber($value)?></td>
                                         <td class="" id="update|money|invoiceitems|tax|<?php echo $item['id']?>">$<?php echo formatnumber($tax)?></td>
                                        <td>$<?php echo formatnumber($total)?></td>
                                    </tr>
<?php } ?>
                                    <tr>
                                        <td><div><strong class="" id="update|select|invoiceitems|id_invoice|<?php echo $invoice['id']?>||products|description| | | "></strong></div>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>                                    
                                    </tbody>
                                </table>
                            </div><!-- /table-responsive -->

                            <table class="table invoice-total">
                                <tbody>
                                <tr>
                                    <td><strong>Sub Total :</strong></td>
                                    <td>$<?php echo formatnumber($totalSub)?></td>
                                </tr>
                                <tr>
                                    <td><strong>TAX :</strong></td>
                                    <td>$<?php echo formatnumber($totalTax)?></td>
                                </tr>
                                <tr>
                                    <td><strong>TOTAL :</strong></td>
                                    <td>$<?php echo formatnumber($totalGran)?></td>
                                </tr>
                                </tbody>
                            </table>

                            <div class="well m-t"><strong>Comments</strong><br/>
                                <span class="edit_area" id="update|text|invoices|obs|<?php echo $invoice['id']?>"><?php echo nl2br($invoice['obs'])?></span>
                            </div>
                        </div>
                </div>
            </div>
        </div>
        <div class="footer">
        	<div>
            	<strong>Copyright</strong> <a href="http://www.foi.tech">Foi.Tech</a> &copy; <?php echo date("Y")?>
            </div>
        </div>

        </div>
        </div>
</body>
<?php include("part_scripts.php")?>
</html>
