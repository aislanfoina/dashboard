<?php require("../common/config.php")?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
<?php include("part_topbar.php");?>   
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Lista de Faturas</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="main.php">Home</a>
                        </li>
                        <li class="active">
                            <strong>Faturas</strong>
                        </li>
                    </ol>
                </div>
            </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInUp">

                    <div class="ibox">
                        <div class="ibox-title">
                            <h5>Todos as faturas vinculados com essa conta</h5>
                            <div class="ibox-tools">
                                <a class="btn btn-primary btn-xs" id="api|new_invoice">Criar nova fatura</a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <div class="row m-b-sm m-t-sm">
                                <div class="col-md-1">
                                    <button type="button" id="loading-example-btn" class="btn btn-white btn-sm" onclick="location.reload();" ><i class="fa fa-refresh"></i> Atualizar</button>
                                </div>
                                <div class="col-md-11">
                                    <div class="input-group"><input type="text" placeholder="Pesquisa" class="input-sm form-control" id="search_form"> <span class="input-group-btn">
                                        <button type="button" class="btn btn-sm btn-primary"> Buscar</button> </span></div>
                                </div>
                            </div>

                            <div class="project-list">

                                <table class="table table-hover">
                                    <tbody>
<?php $invoices = $dao['invoices']->getValid(); foreach($invoices as $invoice) { ?>                                    
                                    <tr>
                                        <td class="project-status">
                                            <span class="label <?php echo getStatusLabel($invoice['id_status'])?>"><?php echo $invoice['status']?></span>
                                        </td>
                                        <td class="project-title">
                                            <a href="invoice_detail.php?id=<?php echo $invoice['id']?>" id="search_field|<?php echo $invoice['id']?>"><?php echo $invoice['id']?> - <?php echo $invoice['cust_name']?> - <?php echo $invoice['project_name']?></a>
                                            <br/>
                                            <small><?php echo $invoice['project_resume']?></small>
                                        </td>
                                        <td>
                                        	<small>Valor: <?php echo $invoice['unicode'].formatnumberBR($invoice['total']+$invoice['total_tax'])?></small>
                                        </td>
                                        <td class="project-completion">
                                                <small>Vencimento: <?php echo date("d-m-y", strtotime($invoice['due_date']))?></small>
                                                <div class="progress progress-mini">
                                                    <div style="width: <?php echo getProgressPercent($invoice['issue_date'], $invoice['due_date'])?>%;" class="progress-bar"></div>
                                                </div>
                                        </td>
<!--                                         <td class="project-people"> -->
<!--                                            <a href=""><img alt="image" class="img-circle" src="img/a<?php echo ($invoice['id']%5)+1?>.jpg"></a>-->
<!--                                         </td> -->
<!--                                         <td class="project-badges"> -->
<!--                                         	<span class="label <?php echo getStatusLabel($invoice['id_priority'])?>"><?php echo $invoice['priority']?></span> -->
<!--                                         </td> -->
                                        <td class="project-actions">
                                            <a class="btn btn-white btn-sm" id="api|pay_invoice|<?php echo $invoice['id']?>"><i class="fa fa-dollar"></i> Pay</a>
                                            <a class="btn btn-white btn-sm share_btn" data-clipboard-text="http://foi.tech/erp/br/invoice_print_br.php?number=<?php echo $invoice['number']?>"><i class="fa fa-link"></i> Share </a>
                                        </td>
                                    </tr>
<?php } ?>                                    
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
            <div class="footer">
<?php include("part_footer.php")?>
            </div>
        
        
        
        
        
        </div>
    </div>
</body>
<?php include("part_scripts.php")?>
</html>
