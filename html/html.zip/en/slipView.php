<?php require("../common/config.php")?>
<?php // include("tool_auth.php"); ?>
<?php

if(_any('id_project')) {
	$id_project = _any('id_project');
	
	include("tool_gerar_boleto_bb.php");
	
	// N�O ALTERAR!
	include("../common/boletophp/include/funcoes_bb.php"); 
	include("../common/boletophp/include/layout_bb.php");
	
	if(_any('salvarSlip')) {
		$dao['slips']->saveSlipbySliparr($dadosboleto, $company, $project);
?>
<script>
	window.print();
</script>
<?php 
	} else { ?>
<script>
	var url = window.location.href;
	if(confirm('Salvar Boleto?'))
		window.location.href = url+'&salvarSlip=true';
</script>
<?php 
	}
}
else if(_any('id_slip')||_any('slip_ournumber')) {
	if(_any('id_slip')) {
		$id = _any('id_slip');
		$slip = $dao['slips']->getSlipbyId($id)[0];
	}
	else {
		$id = _any('slip_ournumber');
		$slip = $dao['slips']->getSlipbyOurnumber($id)[0];
	}
	
	$dao['journals']->saveSlipAccessJournal($slip['id']);
	
	$project = $dao['projects']->getProjectbyId($slip['id_project'])[0];
	$company = $dao['companies']->getCompanybyId($slip['id_customer'])[0];
	$sender = $dao['companies']->getCompanybyId(1)[0];
	
	$contrato = $project['contract'];//"PS-a301/2014";
	$id = $company['id'];//"2";
	$razao = $company['name']." - ".($company['id_type']==4?"CPF ":"CNPJ ").$company['cpf_cnpj'];//"Fabio Colombini ME - CNPJ 59.544.908/0001-09";
	$endereco = $company['address'].", ".$company['address_number']." - ".$company['address_complement'];//"Alameda dos Maracatins, 426 - cj 411";
	$cidade = $company['city'];//"Sao Paulo";
	$estado = $company['state'];//"SP";
	$cep = $company['zip'];//"04089-000";
	
	$nossonumero = $slip['our_number'];
	
	$issueData = $slip['issue_date'];
	$data_venc = date("d/m/Y", strtotime($slip['expiration_date']));  // Prazo de X dias OU informe data: "13/04/2006";
	$valor_boleto=number_format($slip['value'], 2, ',', '');
	
	$description_arr = explode("\n",$slip['description']);
	$instructions_arr = explode("\n",$slip['instructions']);
	
	$dadosboleto["nosso_numero"] = $nossonumero;
	$dadosboleto["numero_documento"] = $contrato;	// Num do pedido ou do documento
	$dadosboleto["data_vencimento"] = $data_venc; // Data de Vencimento do Boleto - REGRA: Formato DD/MM/AAAA
	$dadosboleto["data_documento"] = date("d/m/Y", strtotime($issueData)); // Data de emiss�o do Boleto
	$dadosboleto["data_processamento"] = date("d/m/Y", strtotime($issueData)); // Data de processamento do boleto (opcional)
	$dadosboleto["valor_boleto"] = $valor_boleto; 	// Valor do Boleto - REGRA: Com v�rgula e sempre com duas casas depois da virgula
	
	// DADOS DO SEU CLIENTE
	$dadosboleto["sacado"] = $razao;
	$dadosboleto["endereco1"] = $endereco;
	$dadosboleto["endereco2"] = "$cidade - $estado -  CEP: $cep";
	
	// INFORMACOES PARA O CLIENTE
	$dadosboleto["demonstrativo1"] = $description_arr[0];
	$dadosboleto["demonstrativo2"] = $description_arr[1];
	$dadosboleto["demonstrativo3"] = $description_arr[2];
	
	// INSTRU��ES PARA O CAIXA
	$dadosboleto["instrucoes1"] = $instructions_arr[0];
	$dadosboleto["instrucoes2"] = $instructions_arr[1];
	$dadosboleto["instrucoes3"] = $instructions_arr[2];
	$dadosboleto["instrucoes4"] = $instructions_arr[3];
	
	// DADOS OPCIONAIS DE ACORDO COM O BANCO OU CLIENTE
	$dadosboleto["quantidade"] = "";
	$dadosboleto["valor_unitario"] = "";
	$dadosboleto["aceite"] = "N";
	$dadosboleto["especie"] = "R$";
	$dadosboleto["especie_doc"] = "DM";
	
	// ---------------------- DADOS FIXOS DE CONFIGURA��O DO SEU BOLETO --------------- //
	
	// DADOS DA SUA CONTA - BANCO DO BRASIL
	$dadosboleto["agencia"] = "3559"; // Num da agencia, sem digito
	$dadosboleto["conta"] = "47747"; 	// Num da conta, sem digito
	
	// DADOS PERSONALIZADOS - BANCO DO BRASIL
	$dadosboleto["convenio"] = "2553527";  // Num do conv�nio - REGRA: 6 ou 7 ou 8 d�gitos
	$dadosboleto["contrato"] = "19059981"; // Num do seu contrato
	$dadosboleto["carteira"] = "18";
	$dadosboleto["variacao_carteira"] = "-019";  // Varia��o da Carteira, com tra�o (opcional)
	
	// TIPO DO BOLETO
	$dadosboleto["formatacao_convenio"] = "7"; // REGRA: 8 p/ Conv�nio c/ 8 d�gitos, 7 p/ Conv�nio c/ 7 d�gitos, ou 6 se Conv�nio c/ 6 d�gitos
	$dadosboleto["formatacao_nosso_numero"] = "2"; // REGRA: Usado apenas p/ Conv�nio c/ 6 d�gitos: informe 1 se for NossoN�mero de at� 5 d�gitos ou 2 para op��o de at� 17 d�gitos
	$dadosboleto["identificacao"] = utf8_encode($sender['name']);//"FOITEC TECNOLOGIA DA INFORMA��O LTDA";
	
	$dadosboleto["cpf_cnpj"] = $sender['cpf_cnpj'];//"17.879.204/0001-47";
	$dadosboleto["endereco"] = $sender['address'];//"SHCN CL QD 205 BL A LJ 18";
	$dadosboleto["cidade_uf"] = $sender['city']." / ".$sender['state'];//"Brasilia / DF";
	$dadosboleto["cedente"] = utf8_encode($sender['name']);//"FOITEC TECNOLOGIA DA INFORMA��O LTDA";
	
	// N�O ALTERAR!
	include("../common/boletophp/include/funcoes_bb.php");
	include("../common/boletophp/include/layout_bb.php");
?>
<script>
	window.print();
</script>
<?php 	
}
?>
