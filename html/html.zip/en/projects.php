<?php require("../common/config.php")?>
<?php 
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
<?php include("part_topbar.php");?>   
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Lista de Processos</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="main.php">Home</a>
                        </li>
                        <li class="active">
                            <strong>Projetos</strong>
                        </li>
                    </ol>
                </div>
            </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInUp">

                    <div class="ibox">
                        <div class="ibox-title">
                            <h5>Todos os projetos vinculados a essa empresa</h5>
                            <div class="ibox-tools">
                                <a href="" class="btn btn-primary btn-xs">Criar novo projecto</a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <div class="row m-b-sm m-t-sm">
                                <div class="col-md-1">
                                    <button type="button" id="loading-example-btn" class="btn btn-white btn-sm" onclick="location.reload();" ><i class="fa fa-refresh"></i> Atualizar</button>
                                </div>
                                <div class="col-md-11">
                                    <div class="input-group"><input type="text" placeholder="Pesquisa" class="input-sm form-control" id="search_form"> <span class="input-group-btn">
                                        <button type="button" class="btn btn-sm btn-primary"> Buscar</button> </span></div>
                                </div>
                            </div>

                            <div class="project-list">

                                <table class="table table-hover">
                                    <tbody>
<?php $projects = $dao['projects']->get(); foreach($projects as $project) { ?>                                    
                                    <tr>
                                        <td class="project-status">
                                            <span class="label <?php echo getStatusLabel($project['id_status'])?>"><?php echo $project['status']?></span>
                                        </td>
                                        <td class="project-title">
                                            <a href="project_detail.php?id=<?php echo $project['id']?>" id="search_field|<?php echo $project['id']?>"><?php echo $project['id']?> - <?php echo $project['customer']?> - <?php echo $project['name']?></a>
                                            <br/>
                                            <small><?php echo $project['resume']?></small>
                                        </td>
                                        <td class="project-completion">
                                                <small>Progresso: <?php echo $progress = getProgressStartProjectPercent($project['start_date']);?>%</small>
                                                <div class="progress progress-mini">
                                                    <div style="width: <?php echo $progress?>%;" class="progress-bar"></div>
                                                </div>
                                        </td>
                                        <td class="project-people">
                                            <a href=""><img alt="image" class="img-circle" src="img/a<?php echo ($project['id']%5)+1?>.jpg"></a>
                                        </td>
                                        <td class="project-badges">
                                        	<span class="label <?php echo getStatusLabel($project['id_priority'])?>"><?php echo $project['priority']?></span>
                                        </td>
                                        <td class="project-actions">
                                            <a href="project_detail.php?id=<?php echo $project['id']?>" class="btn btn-white btn-sm"><i class="fa fa-folder"></i> Ver</a>
                                            <a href="project_detail.php?id=<?php echo $project['id']?>&edit" class="btn btn-white btn-sm"><i class="fa fa-pencil"></i> Editar </a>
                                        </td>
                                    </tr>
<?php } ?>                                    
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
            <div class="footer">
<?php include("part_footer.php")?>
            </div>
        
        
        
        
        
        </div>
    </div>
</body>
<?php include("part_scripts.php")?>
</html>
