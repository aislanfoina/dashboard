<?php require("../common/config.php")?>
<?php 
$id = (_any('id')?_any('id'):'1');
$invoice = $dao['invoices']->getbyId($id);
$items = $dao['invoiceitems']->getItemsbyIdInvoice($id);

$_SESSION['id_invoice'] = $id;
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?></head>
<body>
    <div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
<?php include("part_topbar.php");?>   
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-6">
                    <h2>Fatura</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="main.php">Home</a>
                        </li>
                        <li>
                            <a href="invoices.php">Faturas</a>
                        </li>
                        <li class="active">
                            <strong>Detalhes da Fatura</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-6">
                    <div class="title-action">
                        <a href="#" class="btn btn-white" id="api|edit_invoice"><i class="fa fa-pencil"></i> Edit </a>
                        <a href="#" class="btn btn-white" id="api|save_invoice"><i class="fa fa-check "></i> Save </a>
                        <a href="#" class="btn btn-white" id="api|del_invoice"><i class="fa fa-times "></i> Delete </a>
                        <a href="#" class="btn btn-white" id="api|pay_invoice"><i class="fa fa-dollar "></i> Paid </a>
                        <a href="invoice_print.php?number=<?php echo $invoice['number']?>" target="_blank" class="btn btn-primary"><i class="fa fa-print"></i> Print </a>
                        <a class="btn btn-primary share_btn" data-clipboard-text="http://foi.tech/erp/br/invoice_print_br.php?number=<?php echo $invoice['number']?>"> <i class="fa fa-link"></i> BR </a>
                    </div>
                </div>
            </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInRight">
                    <div class="ibox-content p-xl">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h4>Project: </h4>
                                    <h4 class="text-navy edit_select" id="update|select|invoices|id_project|<?php echo $invoice['id']?>||projects|name| | |<?php echo $invoice['project_id']?>"><?php echo $invoice['project_name']?></h4>
                                    <h5>From:</h5>
                                    <address>
                                        <strong class="edit_select" id="update|select|invoices|id_issuer|<?php echo $invoice['id']?>||companies|name|id_type|1|<?php echo $invoice['issuer_id']?>"><?php echo $invoice['issuer_name']?></strong><br>
                                        <?php echo $invoice['issuer_address_number']?> <?php echo $invoice['issuer_address']?><?php echo ($invoice['issuer_address_complement']!=""?", ".$invoice['issuer_address_complement']:"")?><br>
                                        <?php echo $invoice['issuer_city']?>, <?php echo $invoice['issuer_state']?> <?php echo $invoice['issuer_zip']?><br>
                                        <abbr title="Phone">P:</abbr> <?php echo $invoice['issuer_phone']?>
                                    </address>
                                    <h5>Currency:</h5>
                                    <h5 class="text-navy edit_select" id="update|select|invoices|currency|<?php echo $invoice['id']?>||currencies|id| | |<?php echo $invoice['currency']?>"><?php echo $invoice['currency']?></h5>
                                </div>

                                <div class="col-sm-6 text-right">
                                    <h4>Invoice No.</h4>
                                    <h4 class="text-navy edit" id="update|text|invoices|number|<?php echo $invoice['id']?>"><?php echo $invoice['number']?></h4>
                                    <span>To:</span>
                                    <address>
                                        <strong class="edit_select" id="update|select|invoices|id_customer|<?php echo $invoice['id']?>||companies|name|id_type|2,3,4|<?php echo $invoice['cust_id']?>"><?php echo $invoice['cust_name']?></strong><br>
                                        <?php echo $invoice['cust_address_number']?> <?php echo $invoice['cust_address']?><?php echo ($invoice['cust_address_complement']!=""?", ".$invoice['cust_address_complement']:"")?><br>
                                        <?php echo $invoice['cust_city']?>, <?php echo $invoice['cust_state']?> <?php echo $invoice['cust_zip']?><br>
                                        <abbr title="Phone">P:</abbr> <?php echo $invoice['cust_phone']?>
                                    </address>
                                    <p>
                                        <span><strong>Invoice Date:</strong> <span class="edit" id="update|date|invoices|issue_date|<?php echo $invoice['id']?>"><?php echo date("m-d-y", strtotime($invoice['issue_date']))?></span></span><br/>
                                        <span><strong>Due Date:</strong> <span class="edit" id="update|date|invoices|due_date|<?php echo $invoice['id']?>"><?php echo date("m-d-y", strtotime($invoice['due_date']))?></span></span>
                                    </p>
                                </div>
                            </div>

                            <div class="table-responsive m-t">
                                <table class="table invoice-table">
                                    <thead>
                                    <tr>
                                        <th>Item List</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Tax</th>
                                        <th>Total Price</th>
                                    </tr>
                                    </thead>
                                    <tbody>
<?php 
	$totalSub = 0;
	$totalTax = 0;
	$totalGran = 0;
	foreach ($items as $item) { 
		$qty = $item['quantity'];
		$value = $item['value'];
		$tax = $item['tax'];
		$total = $qty*($value+$tax);
		$totalSub += $qty*$value;
		$totalTax += $qty*$tax;
		$totalGran += $total;
?>                                    
                                    <tr class="item">
                                        <td><div><a id="api|del_invoice_item|<?php echo $item['id']?>" class="del_item"><i class="fa fa-times"></i></a><strong class="edit_select" id="update|select|invoiceitems|id_product|<?php echo $item['id']?>||products|description| | |<?php echo $item['id']?>"><?php echo $item['description']?></strong></div>
                                            <small class="edit" id="update|text|invoiceitems|obs|<?php echo $item['id']?>"><?php echo $item['obs']?></small></td>
                                        <td class="edit itemqty" id="update|text|invoiceitems|quantity|<?php echo $item['id']?>"><?php echo $qty?></td>
                                        <td class="edit itemvalue" id="update|money|invoiceitems|value|<?php echo $item['id']?>"><?php echo $invoice['unicode'].formatnumber($value)?></td>
                                         <td class="edit itemtax" id="update|money|invoiceitems|tax|<?php echo $item['id']?>"><?php echo $invoice['unicode'].formatnumber($tax)?></td>
                                        <td class="itemtotal"><?php echo $invoice['unicode'].formatnumber($total)?></td>
                                    </tr>
<?php } ?>
                                    <tr>
                                        <td><div><strong class="edit_select" id="update|select|invoiceitems|id_invoice|<?php echo $invoice['id']?>||products|description| | | "></strong></div>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>                                    
                                    </tbody>
                                </table>
                            </div><!-- /table-responsive -->

                            <table class="table invoice-total">
                                <tbody>
                                <tr>
                                    <td><strong>Sub Total :</strong></td>
                                    <td class="totalsub"><?php echo $invoice['unicode'].formatnumber($totalSub)?></td>
                                </tr>
                                <tr>
                                    <td><strong>TAX :</strong></td>
                                    <td class="totaltax"><?php echo $invoice['unicode'].formatnumber($totalTax)?></td>
                                </tr>
                                <tr>
                                    <td><strong>TOTAL :</strong></td>
                                    <td class="total"><?php echo $invoice['unicode'].formatnumber($totalGran)?></td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="text-right">
                                <button class="btn btn-primary" onclick="window.open('slipView.php?id_project=<?php echo $invoice['project_id']?>&value=<?php echo $totalGran?>')"><i class="fa fa-money"></i> Generate Slip</button>
                                <button class="btn btn-primary"><i class="fa fa-dollar"></i> Make A Payment</button>
                            </div>

                            <div class="well m-t"><strong>Comments</strong><br/>
                                <span class="edit_area" id="update|text|invoices|obs|<?php echo $invoice['id']?>"><?php echo nl2br($invoice['obs'])?></span>
                            </div>
                           <div class="row m-t-sm">
                                <div class="col-lg-12">
                                <div class="panel blank-panel">
                                <div class="panel-heading">
                                    <div class="panel-options">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#tab-1" data-toggle="tab">Notes</a></li>
                                            <li class=""><a href="#tab-2" data-toggle="tab">Journal</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="panel-body">

                                <div class="tab-content">
                                <div class="tab-pane active" id="tab-1">
                                    <div class="feed-activity-list">
<!--                                         <div class="feed-element"> -->
<!--                                             <a href="#" class="pull-left"> -->
<!--                                                 <img alt="image" class="img-circle" src="img/a2.jpg"> -->
<!--                                             </a> -->
<!--                                             <div class="media-body "> -->
<!--                                                 <small class="pull-right">2h ago</small> -->
<!--                                                 <strong>Marcos Johnson</strong> escreveu para <strong>Henrique Arake</strong>. <br> -->
<!--                                                <small class="text-muted">Today 2:10 pm - <?php echo date("d-m-y")?></small>-->
<!--                                                 <div class="well"> -->
<!--                                                     Processo consta seus dados e está disponivel na justiça eletrônica. -->
<!--                                                 </div> -->
<!--                                             </div> -->
<!--                                         </div> -->
<!--                                         <div class="feed-element"> -->
<!--                                             <a href="#" class="pull-left"> -->
<!--                                                 <img alt="image" class="img-circle" src="img/a4.jpg"> -->
<!--                                             </a> -->
<!--                                             <div class="media-body "> -->
<!--                                                 <small class="pull-right text-navy">5h ago</small> -->
<!--                                                 <strong>Cristiano Johnatan</strong> abriu o processo com <strong>Henrique Arake</strong>. <br> -->
<!--                                                <small class="text-muted">Ontem 1:21 pm - <?php echo date("d-m-y", strtotime("yesterday"))?></small>-->
<!--                                                 <div class="actions"> -->
<!--                                                     <a class="btn btn-xs btn-white"><i class="fa fa-thumbs-up"></i> Curtir </a> -->
<!--                                                     <a class="btn btn-xs btn-white"><i class="fa fa-star"></i> Favorito</a> -->
<!--                                                 </div> -->
<!--                                             </div> -->
<!--                                         </div> -->
<?php foreach($dao['notes']->getNotesbyIdTable($invoice['id'], 'invoices') as $note) {?>
                                        <div class="feed-element">
                                            <a href="#" class="pull-left">
                                                <img alt="image" class="img-circle" src="img/a2.jpg">
                                            </a>
                                            <div class="media-body ">
                                                <small class="pull-right">2h ago</small>
                                                <strong><?php echo $note['owner']?></strong> postou: <br>
                                                <small class="text-muted"><strong><?php echo $note['title']?></strong> <?php echo date("h:i a - d-m-y", strtotime($note['creation_date']))?></small><br>
                                                <div class="well">
                                                    <?php echo $note['description']?>
                                                </div>
                                                <div class="actions">
                                                    <a class="btn btn-xs btn-white"><i class="fa fa-thumbs-up"></i> Editar</a>
                                                    <a class="btn btn-xs btn-white"><i class="fa fa-star"></i> Apagar</a>
                                                </div>
                                                
                                            </div>
                                        </div>
<?php } ?>                                 
										<div class="form-group">
                              				<label>Note</label>
                                			<input class="form-control" id="notes_title" placeholder="Title" type="text"/>
                                			<textarea class="form-control" id="notes_description" placeholder="Your note" rows="3"></textarea>
                            			</div>
                           				<a class="btn btn-xs btn-primary" id="api|save_invoice_note">Save</a>       
                                    </div>

                                </div>
                                <div class="tab-pane" id="tab-2">

                                    <table class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th>Status</th>
                                            <th>Event</th>
                                            <th>Description</th>
                                            <th>Event Date</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
<?php foreach($dao['journals']->getJournalsbyIdTable($invoice['id'], 'invoices') as $note) {?>
                                        <tr>
                                            <td>
                                                <span class="label label-primary"><i class="fa fa-check"></i> Finalizado</span>
                                            </td>
                                            <td>
                                               <?php echo $note['title']?>
                                            </td>
                                            <td>
                                            <p class="small">
                                                <?php echo $note['description']?>
                                            </p>
                                            </td>
                                            <td>
                                               <?php echo date("H:i:s d/m/Y", strtotime($note['creation_date']))?>
                                            </td>
                                            <td>
                                               <?php //echo date("d-m-Y")?>
                                            </td>

                                        </tr>
<?php } ?>                                        
                                        
                                        </tbody>
                                    </table>

                                </div>
                                </div>

                                </div>

                                </div>
                                </div>
                            </div>
                        </div>
                            
                </div>
            </div>
        </div>
        <div class="footer">
<?php include("part_footer.php")?>
        </div>

        </div>
        </div>
</body>
<?php include("part_scripts.php")?>
<script>
function edit_update() {
	var totalsub = 0;
	var totaltax = 0;
	var total = 0;
	var item_cur = '$';
	$('.invoice-table  > tbody  > tr.item').each(function() {
		$this = $(this);
		var item_value = parseFloat($this.find(".itemvalue").html().replace(/[^\d\.]/g,''));
		item_cur = $this.find(".itemvalue").html().replace(/[\d\.\,]/g,'');
		var item_quantity = parseFloat($this.find(".itemqty").html().replace(/[^\d\.]/g,''));
		var item_tax = parseFloat($this.find(".itemtax").html().replace(/[^\d\.]/g,''));
		var item_total = item_quantity*(item_value+item_tax);
		totalsub += item_value*item_quantity;
		totaltax += item_tax*item_quantity;
		total += item_total;
		$this.find(".itemtotal").html(item_cur.concat(item_total.toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")));
	});
	$(".totalsub").html(item_cur.concat(totalsub.toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")));
	$(".totaltax").html(item_cur.concat(totaltax.toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")));
	$(".total").html(item_cur.concat(total.toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")));
}
function edit_select_update() {
	location.reload();
}

$(document).ready(function() {
	$(".del_item").click(function() {
		var row = $(this).closest("tr");
		row.remove();
		edit_update();
	});
});

</script>
</html>
