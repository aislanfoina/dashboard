            <div class="row animated fadeInRight">
                <div class="ibox ">
                    <div class="ibox-content">
                        <div class="tab-content">
                            <div id="contact-1" class="tab-pane active">
                                <div class="row m-b-lg">
                                        <div class="text-center">
                                            <h2>Nicki Smith</h2>
                                            <div class="m-b-sm">
                                                <img alt="image" class="img-circle" src="img/a2.jpg" style="width: 62px">
                                            </div>
                                        </div>
                                        
                                        <div class="text-center">
                                            <strong>
                                                Sobre mim
                                            </strong>
                                            <p>
                                                Advogado especializado em Direito de Família e Direito Penal.
                                            </p>
                                    </div>
                                    </div>
                                    
                                <div class="client-detail">
                                	<form id="frm-review" method="post" action="main.php?type=customer">
                                        <div class="full-height-scroll text-center">
                                        <h3><strong>Avaliação</strong></h3>
                                        <div class="ibox-content">
                                            <div class="m-b-sm">
                                                <small ><strong>Exemplo:</strong> O advogado demonstrou domínio do conteúdo e segurança durante o atendimento? Ele estava dsponível? Mostrou-se diligente? Atrasou ao compromisso?</small>
                                            </div>
                                            
                                           <input id="input-6b" class="rating" data-size="md" data-min="0" data-max="5" data-show-caption="false">
                                            
                                            </div>
                                        
                                            <div class="social-footer">
                                                <div class="social-comment">
                                                    <a href="#" class="pull-left">
                                                        <img alt="image" src="img/a3.jpg">
                                                    </a>
                                                    <div class="media-body">
                                                        <textarea name="notes_description" class="form-control" placeholder="Escreva comentário..."></textarea>
                                                    	<input type="hidden" name="notes_title" value="Review - 3"/>
                                                    	<input type="hidden" name="notes_id_rel" value="1"/>
                                                    	<input type="hidden" name="notes_rel_table" value="users"/>
                                                    	<input type="hidden" name="notes_id_status" value="1"/>
                                                    	<input type="hidden" name="notes_id_owner" value="<?php echo $_SESSION[$cfgPrefix.'_userId']?>"/>
                                                    </div><br>
                                                    <button type="submit" name="action"  value="save" class="btn btn-primary btn-sm btn-block"><i class="fa fa-envelope"></i> Enviar avaliação </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
            </div>
