<?php require("../common/config.php")?>
<?php 
$number = (_any('number')?_any('number'):'SRV-1601001A-00');
$invoice = $dao['invoices']->getInvoicebyNumber($number);
// $invoice = $dao['invoices']->getbyId($id);
$items = $dao['invoiceitems']->getItemsbyIdInvoice($invoice['id']);

$dao['journals']->saveInvoiceAccessJournal($invoice['id']);
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?></head>
</head>

<body class="white-bg">
                <div class="wrapper wrapper-content p-xl">
                    <div class="ibox-content p-xl">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h5>De:</h5>
                                    <address>
                                        <strong><?php echo utf8_encode($invoice['issuer_name'])?></strong><br>
                                        <?php echo $invoice['issuer_address']?> <?php echo $invoice['issuer_address_number']?> <?php echo ($invoice['issuer_address_complement']!=""?", ".$invoice['issuer_address_complement']:"")?><br>
                                        <?php echo $invoice['issuer_city']?>, <?php echo $invoice['issuer_state']?> <?php echo $invoice['issuer_zip']?><br>
                                        <abbr title="Phone">F:</abbr> <?php echo $invoice['issuer_phone']?>
                                    </address>
                                </div>

                                <div class="col-sm-6 text-right">
                                    <h4>Fatura No.</h4>
                                    <h4 class="text-navy"><?php echo $invoice['number']?></h4>
                                    <span>Para:</span>
                                    <address>
                                        <strong><?php echo $invoice['cust_name']?></strong><br>
                                        <?php echo $invoice['cust_address']?> <?php echo $invoice['cust_address_number']?> <?php echo ($invoice['cust_address_complement']!=""?", ".$invoice['cust_address_complement']:"")?><br>
                                        <?php echo $invoice['cust_city']?>, <?php echo $invoice['cust_state']?> <?php echo $invoice['cust_zip']?><br>
                                        <abbr title="Phone">F:</abbr> <?php echo $invoice['cust_phone']?>
                                    </address>
                                    <p>
                                        <span><strong>Data da Fatura:</strong> <?php echo date("d/m/y", strtotime($invoice['issue_date']))?></span><br/>
                                        <span><strong>Data Vencimento:</strong> <?php echo date("d/m/y", strtotime($invoice['due_date']))?></span>
                                    </p>
                                </div>
                            </div>

                            <div class="table-responsive m-t">
                                <table class="table invoice-table">
                                    <thead>
                                    <tr>
                                        <th>Item</th>
                                        <th>Quantidade</th>
                                        <th>Preço unitário</th>
                                        <th>Impostos</th>
                                        <th>Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
<?php 
	$totalSub = 0;
	$totalTax = 0;
	$totalGran = 0;
	foreach ($items as $item) { 
		$qty = $item['quantity'];
		$value = $qty*$item['value'];
		$tax = $item['tax'];
		$total = $value+$tax;
		$totalSub += $value;
		$totalTax += $tax;
		$totalGran += $total;
?>                                    
                                    <tr>
                                        <td><div><strong><?php echo $item['description']?></strong></div>
                                            <small><?php echo $item['obs']?></small></td>
                                        <td><?php echo $qty?></td>
                                        <td><?php echo $invoice['unicode'].formatnumberBR($value)?></td>
                                        <td><?php echo $invoice['unicode'].formatnumberBR($tax)?></td>
                                        <td><?php echo $invoice['unicode'].formatnumberBR($total)?></td>
                                    </tr>
<?php } ?>      
                                    </tbody>
                                </table>
                            </div><!-- /table-responsive -->

                            <table class="table invoice-total">
                                <tbody>
                                <tr>
                                    <td><strong>Sub Total :</strong></td>
                                    <td><?php echo $invoice['unicode'].formatnumberBR($totalSub)?></td>
                                </tr>
                                <tr>
                                    <td><strong>Impostos :</strong></td>
                                    <td><?php echo $invoice['unicode'].formatnumberBR($totalTax)?></td>
                                </tr>
                                <tr>
                                    <td><strong>TOTAL :</strong></td>
                                    <td><?php echo $invoice['unicode'].formatnumberBR($totalGran)?></td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="well m-t"><strong>Observações</strong>
                                <?php echo $invoice['obs']?>
                            </div>
                        </div>

    </div>
</body>
<?php include("part_scripts.php")?>
<script type="text/javascript">
    window.print();
</script>
</html>
