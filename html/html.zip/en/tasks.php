<?php require("../common/config.php")?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
<?php include("part_topbar.php");?>   
        <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Página de Tarefas</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index-2.html">Home</a>
                        </li>
                        <li class="active">
                            <strong>Tarefas</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>

        <div class="wrapper wrapper-content  animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-title">
                            <h5>Lista de Prazos</h5>
                            <div class="ibox-tools">
                                <a href="#" class="btn btn-primary btn-xs">Novo</a>
                            </div>
                        </div>
                        <div class="ibox-content">

                            <div class="m-b-lg">

                                <div class="input-group">
                                    <input type="text" placeholder="Escreva aqui sua pesquisa..." class=" form-control">
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-white"> Pesquisar</button>
                                    </span>
                                </div>
                                <div class="m-t-md">

                                    <div class="pull-right">
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-list"></i> </button>
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-pencil"></i> </button>
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-print"></i> </button>
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-cogs"></i> </button>
                                    </div>

                                    <strong>Encontrados 8 prazos.</strong>



                                </div>

                            </div>

                            <div class="table-responsive">
                            <table class="table table-hover issue-tracker">
                                <tbody>
                                <tr>
                                    <td>
                                        <span class="label label-primary">Cumprido</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial da cliente Sra. Maria da Silva.
                                        </small>
                                    </td>
                                    <td>
                                        Henrique Arake
                                    </td>
                                    <td>
                                        12.02.2015 10:00 am
                                    </td>
                                    <td>
                                        <span class="pie">0.52,1.041</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-white btn-xs"> Reabrir</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-primary">Cumprido</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial da cliente Sra. Maria da Silva.
                                        </small>
                                    </td>
                                    <td>
                                        Juliana D'Ávila
                                    </td>
                                    <td>
                                        10.02.2015 05:32 am
                                    </td>
                                    <td>
                                        <span class="pie">3,2</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                                                <button class="btn btn-white btn-xs"> Reabrir</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-primary">Cumprido</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Apelação
                                        </a>

                                        <small>
                                            Redigir apelação do caso do Sr. Joaquim.
                                        </small>
                                    </td>
                                    <td>
                                        Anthony Jackson
                                    </td>
                                    <td>
                                        02.03.2015 06:02 am
                                    </td>
                                    <td>
                                        <span class="pie">1,2</span>
                                        1d
                                    </td>
                                    <td class="text-right">
                                                               <button class="btn btn-white btn-xs"> Reabrir</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-warning">Pendente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial do Sr. Pedro.
                                        </small>
                                    </td>
                                    <td>
                                        Alex Ferguson
                                    </td>
                                    <td>
                                        28.11.2015 05:10 pm
                                    </td>
                                    <td>
                                        <span class="pie">1,2</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-white btn-xs"> Concluir</button>
                                        <button class="btn btn-white btn-xs"> Editar</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-warning">Pendente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Tarefa
                                        </a>

                                        <small>
                                            Agendar reunião com cliente para discussão dos detalhes do processo.
                                        </small>
                                    </td>
                                    <td>
                                        Mark Conor
                                    </td>
                                    <td>
                                        18.09.2015 06:20 pm
                                    </td>
                                    <td>
                                        <span class="pie">3,2</span>
                                        3d
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-white btn-xs"> Concluir</button>
                                        <button class="btn btn-white btn-xs"> Editar</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-warning">Pendente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Feedback
                                        </a>

                                        <small>
                                            Responder aos questionamentos do coordenador
                                        </small>
                                    </td>
                                    <td>
                                        Anna Johnson
                                    </td>
                                    <td>
                                        13.05.2014 09:20 pm
                                    </td>
                                    <td>
                                        <span class="pie">2,7</span>
                                        3d
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-white btn-xs"> Concluir</button>
                                        <button class="btn btn-white btn-xs"> Editar</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-danger">Urgente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial do Sr. Marcelo.
                                        </small>
                                    </td>
                                    <td>
                                        Henrique Arake
                                    </td>
                                    <td>
                                        12.02.2015 10:00 am
                                    </td>
                                    <td>
                                        <span class="pie">0.52,1.041</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                       <button class="btn btn-white btn-xs"> Concluir</button>
                                        <button class="btn btn-white btn-xs"> Editar</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-danger">Urgente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                           Feedback
                                        </a>

                                        <small>
                                            Responder questionamento do cliente sobre processo.
                                        </small>
                                    </td>
                                    <td>
                                        Anna Smith
                                    </td>
                                    <td>
                                        10.02.2015 05:32 am
                                    </td>
                                    <td>
                                        <span class="pie">3,2</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                       <button class="btn btn-white btn-xs"> Concluir</button>
                                        <button class="btn btn-white btn-xs"> Editar</button>
                                    </td>
                                </tr>
                                
                                </tbody>
                            </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>

        
        
            <div class="footer">
<?php include("part_footer.php")?>
            </div>
        </div>
    </div>
</body>
<?php include("part_scripts.php")?>
</html>
