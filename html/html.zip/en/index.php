<?php require("../common/config.php")?>
<?php
header("location: login.php");
?>