                <div class="pull-right">
                    Existem <strong><?php ?></strong> projetos atualmente no sistema.
                </div>
                <div>
                    <strong>Copyright</strong> <a href="http://www.foi.tech">Foi.Tech</a> &copy; <?php echo date("Y")?>
                </div>
