<?php require("../common/config.php")?>
<?php 
$id = (_any('id')?_any('id'):1);
$comments = $dao['notes']->getReviewsbyId($id);
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?>
</head>
<body>
    <div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
<?php include("part_topbar.php");?>   
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Perfil do Advogado</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index-2.html">Home</a>
                        </li>
                        <li>
                            <a href="index-2.html">Advogados</a>
                        </li>
                        <li class="active">
                            <strong>Perfil</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">


            <div class="row m-b-lg m-t-lg">
                <div class="col-md-6">

                    <div class="profile-image">
                        <img src="img/a4.jpg" class="img-circle circle-border m-b-md" alt="profile">
                    </div>
                    <div class="profile-info">
                        <div class="">
                            <div>
                                <h2 class="no-margins">
                                    Alex Smith
                                </h2>
                                <h4>Advogado Terceirizado</h4>
                                <small>
                                    There are many variations of passages of Lorem Ipsum available, but the majority
                                    have suffered alteration in some form Ipsum available.
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <table class="table small m-b-xs">
                        <tbody>
                        <tr>
                            <td>
                                <strong><?php echo (142+count($comments))?></strong> Avaliações
                            </td>
                            <td>
                                <strong>22</strong> Clientes
                            </td>

                        </tr>
                        <tr>
                            <td>
                                <strong><?php echo count($comments)?></strong> Comentários
                            </td>
                            <td>
                                <strong>54</strong> Peças produzidas
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>154</strong> Respostas
                            </td>
                            <td>
                                <strong>32</strong> Associações
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-3">
                    <small>Avaliações recebidas</small>
                    <h2 class="no-margins"><?php echo (142+count($comments))?></h2>
                    <div id="sparkline1"></div>
                </div>


            </div>
            <div class="row">

                <div class="col-lg-3">

                    <div class="ibox">
                        <div class="ibox-content">
                                <h3>Avalições dos clientes vs. avaliação média dos advogados</h3>

                            <div>
                                    <canvas id="radarChart" height="153"></canvas>
                                </div> 

                        </div>
                    </div>

                    <div class="ibox">
                        <div class="ibox-content">
                            <h3>Avaliação do escritório vs avaliação média dos advogados</h3>
                            <div>
                                    <canvas id="radarChart1" height="153"></canvas>
                                </div> 
                        </div>
                    </div>

                    <div class="ibox">
                        <div class="ibox-content">
                            <h3>Arquivos Pessoais</h3>
                            <ul class="list-unstyled file-list">
                                <li><a href="#"><i class="fa fa-file"></i> Contrato.pdf</a></li>
                                <li><a href="#"><i class="fa fa-file-picture-o"></i> Foto.jpg</a></li>                              
                                <li><a href="#"><i class="fa fa-file-powerpoint-o"></i> Apresentação.pptx</a></li>
                                <li><a href="#"><i class="fa fa-file"></i> Avaliação-2015.docx</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="ibox">
                        <div class="ibox-content">
                            <h3>Mensagem privada</h3>

                            <p class="small">
                                Envie uma mensagem privada para Alex Smith
                            </p>

                            <div class="form-group">
                                <label>Assunto</label>
                                <input type="email" class="form-control" placeholder="Assunto da mensagem">
                            </div>
                            <div class="form-group">
                                <label>Mensagem</label>
                                <textarea class="form-control" placeholder="Sua mensagem" rows="3"></textarea>
                            </div>
                            <button class="btn btn-primary btn-block">Enviar</button>

                        </div>
                    </div>

                </div>

                <div class="col-lg-5">
<?php 
	foreach ($comments as $comment) {
		$rate = str_replace("Review - ", "", $comment['title']);
?>
                    <div class="social-feed-box">
                        <div class="pull-right social-action dropdown">
                            <button data-toggle="dropdown" class="dropdown-toggle btn-white">
                                <i class="fa fa-angle-down"></i>
                            </button>
                            <ul class="dropdown-menu m-t-xs">
                                <li><a href="#">Config</a></li>
                            </ul>
                        </div>
                        <div class="social-avatar">
                            <a href="#" class="pull-left">
                                <img alt="image" src="img/a<?php echo $comment['id_owner']?>.jpg">
                            </a>
                            <div class="media-body">
                                <a href="#">
                                    <?php echo $comment['owner']?>
                                </a>
                                <small class="text-muted"><?php echo date('d.m.Y',strtotime($comment['creation_date']))?></small>
                            </div>
                        </div>
                        <div class="social-body">
                            <p>
                                <?php echo $comment['description']?>
                            </p>
                        </div>
<?php 	if($replies = $dao['notes']->getNotesCommentsbyId($comment['id'])) { ?>
                        <div class="social-footer">
<?php 		foreach ($replies as $reply) { ?>
                            <div class="social-comment">
                                <a href="#" class="pull-left">
                                    <img alt="image" src="img/a<?php echo $reply['id']?>.jpg">
                                </a>
                                <div class="media-body">
                                    <a href="#">
                                        <?php echo $reply['owner']?> (equipe interna)
                                    </a>
                                    <?php echo $reply['description']?> -
                                    <small class="text-muted"><?php echo date('d.m.Y',strtotime($reply['creation_date']))?></small>
                                </div>
                            </div>
<?php 		} ?>
						</div>
<?php 	} ?>                            
                    </div>
<?php } ?>

                </div>
                <div class="col-lg-4 m-b-lg">
                    <div id="vertical-timeline" class="vertical-container light-timeline no-margins">
                        <div class="vertical-timeline-block">
                            <div class="vertical-timeline-icon navy-bg">
                                <i class="fa fa-cc-visa"></i>
                            </div>

                            <div class="vertical-timeline-content">
                                <h2>2014.01.1.123456-8 - João de Tal vs Ciclano de Tal</h2>
                                <p>Trata-se de ação de cobrança de título de crédito extrajudicial, devidamente protestado e acompanhado do comprovante de entrega.
                                </p>
                                <span class="vertical-date">
                                    Ajuizamento: <small>15/01/2016</small>
                                </span>
                                <a class="btn btn-primary"><i class="fa fa-check"></i></a>
                                <a class="btn btn-warning btn-outline"><i class="fa fa-warning"></i></a>
                                <a class="btn btn-danger btn-outline"><i class="fa fa-warning"></i></a>            
                            </div>
                        </div>

                        <div class="vertical-timeline-block">
                            <div class="vertical-timeline-icon blue-bg">
                                <i class="fa fa-child"></i>
                            </div>

                            <div class="vertical-timeline-content">
                                <h2>2012.01.1.1234567-8</h2>
                                <p>Trata-se de ação de divórcio consensual com bens no exterior.</p>
                                <span class="vertical-date">
                                    Ajuizamento: <small>15/01/2012</small>
                                </span>
                                <a class="btn btn-primary btn-outline"><i class="fa fa-check"></i></a>
                                <a class="btn btn-warning"><i class="fa fa-warning"></i></a>
                                <a class="btn btn-danger btn-outline"><i class="fa fa-warning"></i></a>            
                            </div>
                        </div>

                        <div class="vertical-timeline-block">
                            <div class="vertical-timeline-icon lazur-bg">
                                <i class="fa fa-archive"></i>
                            </div>

                            <div class="vertical-timeline-content">
                                <h2>2014.01.1.123456-8</h2>
                                <p>Trata-se de ação de cobrança de gratificação de função por tempo de serviço não pagas durante o período de 2010 a 2011</p>
                                <span class="vertical-date">
                                    Ajuizamento: <small>15/01/2014</small>
                                </span>
                                <a class="btn btn-primary btn-outline"><i class="fa fa-check"></i></a>
                                <a class="btn btn-warning btn-outline"><i class="fa fa-warning"></i></a>
                                <a class="btn btn-danger"><i class="fa fa-warning"></i></a>            
                            </div>
                        </div>

                       
                    </div>

                </div>

            </div>

        </div>
        <div class="footer">
<?php include("part_footer.php")?>
        </div>

        </div>
        </div>
</body>
<?php include("part_scripts.php")?>
   <script>
        $(document).ready(function() {


            $("#sparkline1").sparkline([34, 43, 43, 35, 44, 32, 44, <?php echo (48+count($comments))?>], {
                type: 'line',
                width: '100%',
                height: '50',
                lineColor: '#1ab394',
                fillColor: "transparent"
            });
            var radarData = {
        labels: ["Qualidade", "Disponibilidade", "Assiduidade", "Pontualidade", "Celeridade", "Estabelecimento", "Afinidade"],
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(220,220,220,0.2)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [65, 59, 90, 81, 56, 55, 40]
            },
            {
                label: "My Second dataset",
                fillColor: "rgba(26,179,148,0.2)",
                strokeColor: "rgba(26,179,148,1)",
                pointColor: "rgba(26,179,148,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [28, 48, 40, 19, 96, 27, 100]
            }
        ]
    };

    var radarOptions = {
        scaleShowLine: true,
        angleShowLineOut: true,
        scaleShowLabels: false,
        scaleBeginAtZero: true,
        angleLineColor: "rgba(0,0,0,.1)",
        angleLineWidth: 1,
        pointLabelFontFamily: "'Arial'",
        pointLabelFontStyle: "normal",
        pointLabelFontSize: 10,
        pointLabelFontColor: "#666",
        pointDot: true,
        pointDotRadius: 3,
        pointDotStrokeWidth: 1,
        pointHitDetectionRadius: 20,
        datasetStroke: true,
        datasetStrokeWidth: 2,
        datasetFill: true,
        responsive: true,
    }

    var ctx = document.getElementById("radarChart").getContext("2d");
    var myNewChart = new Chart(ctx).Radar(radarData, radarOptions);
            
            var radarData = {
        labels: ["Qualidade", "Disponibilidade", "Assiduidade", "Pontualidade", "Celeridade", "Estabelecimento", "Afinidade"],
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(220,220,220,0.2)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [65, 59, 90, 81, 56, 55, 40]
            },
            {
                label: "My Second dataset",
                fillColor: "rgba(26,179,148,0.2)",
                strokeColor: "rgba(26,179,148,1)",
                pointColor: "rgba(26,179,148,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [28, 48, 40, 19, 96, 27, 100]
            }
        ]
    };

    var radarOptions = {
        scaleShowLine: true,
        angleShowLineOut: true,
        scaleShowLabels: false,
        scaleBeginAtZero: true,
        angleLineColor: "rgba(0,0,0,.1)",
        angleLineWidth: 1,
        pointLabelFontFamily: "'Arial'",
        pointLabelFontStyle: "normal",
        pointLabelFontSize: 10,
        pointLabelFontColor: "#666",
        pointDot: true,
        pointDotRadius: 3,
        pointDotStrokeWidth: 1,
        pointHitDetectionRadius: 20,
        datasetStroke: true,
        datasetStrokeWidth: 2,
        datasetFill: true,
        responsive: true,
    }

    var ctx = document.getElementById("radarChart1").getContext("2d");
    var myNewChart = new Chart(ctx).Radar(radarData, radarOptions);


        });
    </script>
</html>
