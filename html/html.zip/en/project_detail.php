<?php require("../common/config.php")?>
<?php 
$id = _any("id");
$project = $dao['projects']->getbyId($id);

$_SESSION["id_customer"] = $project['id_customer']; 
$_SESSION["id_project"] = $project['id'];
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
<?php include("part_topbar.php");?>   
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Detalhes do Processo</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="main.php">Home</a>
                        </li>
                        <li>
                            <a href="projects.php">Projetos</a>
                        </li>
                        <li class="active">
                            <strong>Detalhes do Projeto</strong>
                        </li>
                    </ol>
                </div>
            </div>
        <div class="row">
            <div class="col-lg-9">
                <div class="wrapper wrapper-content animated fadeInUp">
                    <div class="ibox">
                        <div class="ibox-content">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="m-b-md">
                                        <a href="#" class="btn btn-white btn-xs pull-right">Editar Projeto</a>
                                        <h2><?php echo $project['customer']?> - <?php echo $project['name']?></h2>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-5">
                                    <dl class="dl-horizontal">
                                        <dt>Status:</dt> <dd><span class="label <?php echo getStatusLabel($project['id_status'])?>"><?php echo $project['status']?></span></dd>
                                    </dl>
                                </div>
                                <div class="col-lg-7" id="cluster_info">
                                    <dl class="dl-horizontal" >
                                        <dd><span class="label <?php echo getStatusLabel($project['id_priority'])?>"><?php echo $project['priority']?></span></dd>
                                    </dl>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-lg-5">
                                    <dl class="dl-horizontal">
                                        <dt>Cliente:</dt> <dd><a href="#" class="text-navy"> <?php echo $project['customer']?></a> </dd>
                                        <dt>Parceiro:</dt> <dd><a href="#" class="text-navy"> <?php echo $project['partner']?></a> </dd>
                                        <dt>Movimentações:</dt> <dd>  1</dd>
                                    </dl>
                                </div>
                                <div class="col-lg-7" id="cluster_info">
                                    <dl class="dl-horizontal" >
                                        <dt>Valor:</dt> <dd>R$ <?php echo formatnumber($project['value'])?></a> </dd>
                                        <dt>Data de Criação:</dt> <dd><?php echo date('d-m-Y',strtotime($project['creation_date']))?></dd>
                                        <dt>Última Atualização:</dt> <dd><?php echo date('d-m-Y',strtotime($project['modify_date']))?></dd>
                                        <dt>Responsável:</dt>
                                        <dd class="project-people">
                                        <a href="profile.php"><img alt="image" class="img-circle" src="img/a<?php echo $project['id']?>.jpg"></a>
                                        </dd>
                                        
                                    </dl>
                                </div>
                             </div>
                             <div class="row">
                                <div class="col-lg-5">
                                    <dl class="dl-horizontal">
                                        <dt>Fluxo de projeto:</dt> <dd><?php echo $project['flow']?></dd>
                                    </dl>
                                </div>
                                <div class="col-lg-7" id="cluster_info">
                                    <dl class="dl-horizontal" >
                                        <dt>Categoria:</dt> <dd><?php echo $project['category']?></dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <dl class="dl-horizontal">
                                        <dt>Concluído:</dt>
                                        <dd>
                                            <div class="progress progress-striped active m-b-sm">
                                                <div style="width: <?php echo $progress = getProgressStartProjectPercent($project['start_date'])?>%;" class="progress-bar"></div>
                                            </div>
                                            <small>Este projeto está <strong><?php echo $progress?>%</strong> da sua data de renovação.</small>
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                            <div class="row m-t-sm">
                                <div class="col-lg-12">
                                <div class="panel blank-panel">
                                <div class="panel-heading">
                                    <div class="panel-options">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#tab-1" data-toggle="tab">Anotações do usuário</a></li>
                                            <li class=""><a href="#tab-2" data-toggle="tab">Histórico</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="panel-body">

                                <div class="tab-content">
                                <div class="tab-pane active" id="tab-1">
                                    <div class="feed-activity-list">
<!--                                         <div class="feed-element"> -->
<!--                                             <a href="#" class="pull-left"> -->
<!--                                                 <img alt="image" class="img-circle" src="img/a2.jpg"> -->
<!--                                             </a> -->
<!--                                             <div class="media-body "> -->
<!--                                                 <small class="pull-right">2h ago</small> -->
<!--                                                 <strong>Marcos Johnson</strong> escreveu para <strong>Henrique Arake</strong>. <br> -->
<!--                                                <small class="text-muted">Today 2:10 pm - <?php echo date("d-m-y")?></small>-->
<!--                                                 <div class="well"> -->
<!--                                                     Processo consta seus dados e está disponivel na justiça eletrônica. -->
<!--                                                 </div> -->
<!--                                             </div> -->
<!--                                         </div> -->
<!--                                         <div class="feed-element"> -->
<!--                                             <a href="#" class="pull-left"> -->
<!--                                                 <img alt="image" class="img-circle" src="img/a4.jpg"> -->
<!--                                             </a> -->
<!--                                             <div class="media-body "> -->
<!--                                                 <small class="pull-right text-navy">5h ago</small> -->
<!--                                                 <strong>Cristiano Johnatan</strong> abriu o processo com <strong>Henrique Arake</strong>. <br> -->
<!--                                                <small class="text-muted">Ontem 1:21 pm - <?php echo date("d-m-y", strtotime("yesterday"))?></small>-->
<!--                                                 <div class="actions"> -->
<!--                                                     <a class="btn btn-xs btn-white"><i class="fa fa-thumbs-up"></i> Curtir </a> -->
<!--                                                     <a class="btn btn-xs btn-white"><i class="fa fa-star"></i> Favorito</a> -->
<!--                                                 </div> -->
<!--                                             </div> -->
<!--                                         </div> -->
<?php foreach($dao['notes']->getNotesbyIdTable($project['id'], 'projects') as $note) {?>
                                        <div class="feed-element">
                                            <a href="#" class="pull-left">
                                                <img alt="image" class="img-circle" src="img/a2.jpg">
                                            </a>
                                            <div class="media-body ">
                                                <small class="pull-right">2h ago</small>
                                                <strong><?php echo $note['owner']?></strong> postou: <br>
                                                <small class="text-muted"><strong><?php echo $note['title']?></strong> <?php echo date("h:i a - d-m-y", strtotime($note['creation_date']))?></small><br>
                                                <div class="well">
                                                    <?php echo $note['description']?>
                                                </div>
                                                <div class="actions">
                                                    <a class="btn btn-xs btn-white"><i class="fa fa-thumbs-up"></i> Editar</a>
                                                    <a class="btn btn-xs btn-white"><i class="fa fa-star"></i> Apagar</a>
                                                </div>
                                                
                                            </div>
                                        </div>
<?php } ?>                                 
										<div class="form-group">
                              				<label>Note</label>
                                			<input class="form-control" id="notes_title" placeholder="Title" type="text"/>
                                			<textarea class="form-control" id="notes_description" placeholder="Your note" rows="3"></textarea>
                            			</div>
                           				<a class="btn btn-xs btn-primary" id="api|save_note">Save</a>       
                                    </div>

                                </div>
                                <div class="tab-pane" id="tab-2">

                                    <table class="table table-striped">
                                        <thead>
                                        <tr>
                                            <th>Status</th>
                                            <th>Movimentação</th>
                                            <th>Data de Criação</th>
                                            <th>Data de Conclusão</th>
                                            <th>Comentários</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>
                                                <span class="label label-primary"><i class="fa fa-check"></i> Finalizado</span>
                                            </td>
                                            <td>
                                               Abertura do processo
                                            </td>
                                            <td>
                                               <?php echo date("d-m-Y", strtotime("yesterday"))?>
                                            </td>
                                            <td>
                                               <?php echo date("d-m-Y")?>
                                            </td>
                                            <td>
                                            <p class="small">
                                                <?php echo "Processo aberto na ".$project['vara']." do estado de ".$project['foro']?>.
                                            </p>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <span class="label label-warning"><i class="fa "></i> Em andamento</span>
                                            </td>
                                            <td>
                                               Entrega de documentação
                                            </td>
                                            <td>
                                               <?php echo date("d-m-Y")?>
                                            </td>
                                            <td>
                                               <?php echo ""?>
                                            </td>
                                            <td>
                                            <p class="small">
                                                <?php echo "Aguardando entrega da documentação."?>
                                            </p>
                                            </td>

                                        </tr>
                                        
                                        </tbody>
                                    </table>

                                </div>
                                </div>

                                </div>

                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="wrapper wrapper-content project-manager">
                    <h4>Descrição do Projeto</h4>
<!--                     <img src="img/zender_logo.png" class="img-responsive"> -->
                    <p class="small">
                        <?php echo $project['description']?>
                    </p>
                    <p class="small">
                        Obs: <?php echo $project['obs']?>
                    </p>
                    <p class="small font-bold">
                        Prioridade: <span><i class="fa fa-circle text-warning"></i> <?php echo $project['priority']?></span>
                    </p>
                    <h5>Anexos do Processo</h5>
                    <ul class="list-unstyled project-files">
                        <li><a href=""><i class="fa fa-file"></i> Processo.docx</a></li>
                        <li><a href=""><i class="fa fa-file-picture-o"></i> Foto Perícia.jpg</a></li>
                        <li><a href=""><i class="fa fa-stack-exchange"></i> Email para advogado.txt</a></li>
                        <li><a href=""><i class="fa fa-file"></i> Contrato.pdf</a></li>
                    </ul>
                    <div class="text-center m-t-md">
                        <a href="#" class="btn btn-xs btn-primary">Adicionar arquivo</a>
                        <a href="#" class="btn btn-xs btn-primary" id="api|dup_invoice">Criar fatura</a>
<!--                         <a href="#" class="btn btn-xs btn-primary">Report contact</a> -->
                    </div>
<!--                     <h5>Palavras Chave</h5> -->
                    <ul class="tag-list" style="padding: 0">
<!--                         <li><a href="#"><i class="fa fa-tag"></i> Processo</a></li> -->
<!--                         <li><a href="#"><i class="fa fa-tag"></i> Justiça</a></li> -->
                        
<!--                     </ul> -->
                    
                </div>
            </div>
        </div>
   
            
            <div class="footer">
<?php include("part_footer.php")?>
            </div>

        </div>

    </div>
</body>
<?php include("part_scripts.php")?>
</html>
