<?php require("../common/config.php")?>
<?php header('Access-Control-Allow-Origin: *');?>
<?php 
$start = (_any('start')?_any('start'):date("Y-m-d", strtotime("-1 months")));
$end = (_any('end')?_any('end'):date("Y-m-d"));
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
<?php include("part_topbar.php");?>   
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Relatorio de horas</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="main.php">Home</a>
                        </li>
                        <li>
                            <a>Relatórios</a>
                        </li>
                        <li class="active">
                            <strong>Horas</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Relatorio de horas</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                    	<form role="form" class="form-inline">
							<div class="form-group" id="data_5">
                                <label class="font-noraml">Intervalo de tempo</label>
                                <div class="input-daterange input-group" id="datepicker">
                                    <input type="text" class="input-sm form-control" name="start" value="<?php echo $start?>"/>
                                    <span class="input-group-addon">to</span>
                                    <input type="text" class="input-sm form-control" name="end" value="<?php echo $end?>" />
                                </div>
								<button class="btn btn-white input-sm" type="submit">Generate</button> 
                            </div>
                        </form>
        				<div>
    	                    <canvas id="lineChart1"></canvas>
    	                    <div id="js-legend" class="chart-legend"></div>
	                    </div>  
                    </div>
                </div>
            </div>
        </div>
         <div class="row">
                <div class="col-lg-6">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Total horas por dia</h5>

                        </div>
                        <div class="ibox-content">
                            <div class="text-center">
<!--                                 <canvas id="polarChart" height="140"></canvas> -->
								<div id="ct-chart3" class="ct-perfect-fourth"></div>
<!-- 								<span id="sparkline8"></span> -->

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Total por Cliente </h5>

                        </div>
                        <div class="ibox-content">
                            <div>
                                <canvas id="doughnutChart" height="240"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
        
        
        
            <div class="footer">
<?php include("part_footer.php")?>
            </div>
        </div>
    </div>
</body>
<?php include("part_scripts.php")?>
<script>
	var lineData = {};
	var doughnutData = [];
	var totalPerDay = [];
	lineData.labels = [];// Array();//[];
	lineData.datasets = [];
	var dataPoints = {};
	var dataLabels = [];
	var sumLabels = [];
	var seriesData = [];

    var lineOptions = {
            scaleShowGridLines: true,
            scaleGridLineColor: "rgba(0,0,0,.05)",
            scaleGridLineWidth: 1,
            bezierCurve: true,
            bezierCurveTension: 0.4,
            pointDot: true,
            pointDotRadius: 4,
            pointDotStrokeWidth: 1,
            pointHitDetectionRadius: 20,
            datasetStroke: true,
            datasetStrokeWidth: 2,
            datasetFill: true,
            responsive: true,
            legendTemplate : "<% for (var i=0; i<datasets.length; i++){%><span style=\"background-color:<%=datasets[i].strokeColor%>\">&#9723;</span> <%if(datasets[i].label){%><%=datasets[i].label%><%}%>  <%}%>"
        };
    
    $.ajax({
		url: "http://ws1.iflylo.com/json2.php",
		type: "GET",
		data: { action: 'getdronesreport', start:'<?php echo $start?>', end:'<?php echo $end?>', id_user: 23},
		dataType: 'json',
		success: function(response) {
			console.log(response);
			var arr = $.map(response, function(el) { return el });
			for(var record in response.report) {
				var obj = response.report[record];
				var date = obj.dt_start.split(" ")[0].substring(5);
				var nick = obj.nick;
				var time = obj.total_time;
				if(lineData.labels.indexOf(date) == -1) {
					lineData.labels.push(date);
					dataPoints[date] = [];
				}
				if(dataPoints[date].indexOf(nick) == -1) {
					dataPoints[date][nick] = 0;
				}
				dataPoints[date][nick] += parseInt(time);
				if(dataLabels.indexOf(nick) == -1) {
					dataLabels.push(nick);
					sumLabels[nick] = 0;
				}
			}
			

			for (var nick in dataLabels) {
				var nickLabel = dataLabels[nick];
				seriesData[nick] = [];
				if(nick == 0) {
					lineData.datasets[nick] = {
			                label: nickLabel,
			                fillColor: "rgba(220,220,220,0.5)",
			                strokeColor: "rgba(220,220,220,1)",
			                pointColor: "rgba(220,220,220,1)",
			                pointStrokeColor: "#fff",
			                pointHighlightFill: "#fff",
			                pointHighlightStroke: "rgba(220,220,220,1)",
			                data: []
			        };

					doughnutData[nick] = {
		                    color: "#dedede",
		                    highlight: "#1ab394",
		                    label: nickLabel
			        };
							
				} else if (nick == 1) {
					lineData.datasets[nick] = {
			                label: nickLabel,
			                fillColor: "rgba(26,179,148,0.5)",
			                strokeColor: "rgba(26,179,148,0.7)",
			                pointColor: "rgba(26,179,148,1)",
			                pointStrokeColor: "#fff",
			                pointHighlightFill: "#fff",
			                pointHighlightStroke: "rgba(26,179,148,1)",
			                data: []
					};

					doughnutData[nick] = {
		                    color: "#a3e1d4",
		                    highlight: "#1ab394",
		                    label: nickLabel
			        };

				} else if (nick == 2) {
					lineData.datasets[nick] = {
			                label: nickLabel,
			                fillColor: "rgba(255,147,135,0.5)",
			                strokeColor: "rgba(255,147,135,1)",
			                pointColor: "rgba(255,147,135,1)",
			                pointStrokeColor: "#fff",
			                pointHighlightFill: "#fff",
			                pointHighlightStroke: "rgba(255,147,135,1)",
			                data: []
			        };
					doughnutData[nick] = {
							color: "#FF9387",
		                    highlight: "#1ab394",
		                    label: nickLabel
			        };
				} else if (nick == 3) {
					lineData.datasets[nick] = {
			                label: nickLabel,
			                fillColor: "rgba(122,190,255,0.5)",
			                strokeColor: "rgba(122,190,255,1)",
			                pointColor: "rgba(122,190,255,1)",
			                pointStrokeColor: "#fff",
			                pointHighlightFill: "#fff",
			                pointHighlightStroke: "rgba(122,190,255,1)",
			                data: []
			        };
					doughnutData[nick] = {
							color: "#A4CEE8",
		                    highlight: "#1ab394",
		                    label: nickLabel
			        };
				} 
				else {
					lineData.datasets[nick] = {
			                label: nickLabel,
			                fillColor: "rgba(220,220,220,0.5)",
			                strokeColor: "rgba(220,220,220,1)",
			                pointColor: "rgba(220,220,220,1)",
			                pointStrokeColor: "#fff",
			                pointHighlightFill: "#fff",
			                pointHighlightStroke: "rgba(220,220,220,1)",
			                data: []
			        };
					doughnutData[nick] = {
							color: "#A4CEE8",
		                    highlight: "#1ab394",
		                    label: nickLabel
			        };
				}

			}
			
			for(var day in lineData.labels) {
				var dayLabel = lineData.labels[day];
				totalPerDay[day] = 0;
				for (var nick in dataLabels) {
					var nickLabel = dataLabels[nick];
// 					console.log(dataPoints[dayLabel][nickLabel]);
					if(typeof dataPoints[dayLabel][nickLabel] === 'undefined') {
						lineData.datasets[nick].data.push(0);
						seriesData[nick].push(0);
					}
					else {
						var time = parseFloat(Math.round((dataPoints[dayLabel][nickLabel])/60*10))/10;
						lineData.datasets[nick].data.push(time);
						seriesData[nick].push(time);
						sumLabels[nickLabel] += parseFloat(time)
						totalPerDay[day] += parseFloat(time)
					}
				}
				totalPerDay[day] = totalPerDay[day]; 
			}

			for (var nick in dataLabels) {
				var nickLabel = dataLabels[nick];
				sumLabels[nickLabel] = sumLabels[nickLabel];
				doughnutData[nick].value = Number(parseFloat(sumLabels[nickLabel]).toFixed(2));
			}

		    var ctx = document.getElementById("lineChart1").getContext("2d");
		    var myNewChart = new Chart(ctx).Line(lineData, lineOptions);
		    document.getElementById('js-legend').innerHTML = myNewChart.generateLegend();



            var doughnutOptions = {
                segmentShowStroke: true,
                segmentStrokeColor: "#fff",
                segmentStrokeWidth: 2,
                percentageInnerCutout: 0, // This is 0 for Pie charts
                animationSteps: 40,
                animationEasing: "easeOutBounce",
                animateRotate: true,
                animateScale: false
            };

            var ctx = document.getElementById("doughnutChart").getContext("2d");
            var DoughnutChart = new Chart(ctx).Doughnut(doughnutData, doughnutOptions);


//             $("#sparkline8").sparkline(totalPerDay, {
//                 type: 'bar',
//                 barWidth: 10,
//                 height: '150px',
//                 barColor: '#1ab394',
//                 negBarColor: '#c6c6c6'});


			// Stocked bar chart

            new Chartist.Bar('#ct-chart3', {
                labels: lineData.labels,
                series: seriesData
            }, {
                stackBars: true,
                axisY: {
                    labelInterpolationFnc: function(value) {
                        return (value) + 'h';
                    }
                }
            }).on('draw', function(data) {
                        if(data.type === 'bar') {
                            data.element.attr({
                                style: 'stroke-width: 10px'
                            });
                        }
            });
		},
		error: function (xhr, ajaxOptions, thrownError) {
			console.log(xhr.responseText);
	//			location.reload();
		}
	});


</script>
</html>
