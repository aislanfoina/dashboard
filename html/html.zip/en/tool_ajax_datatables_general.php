<?php require("../common/config.php")?>
<?php

$tableid = _any('id');
$value = utf8_decode(_any('value'));
$column = _any('columnName');
$columnPosition = _any('columnPosition');
$columnId = _any('columnId');
$rowId = _any('rowId');

print_r($_POST);

$tableid = explode("|", $tableid);
$table = $tableid[0];
$idColumn = $tableid[1];
$id = $tableid[2];

if($table != NULL && $id!= NULL) {
	if($table == "tickets") {
		$runQuery = false;
		switch(utf8_decode($column)) {
			case "Resumo":
				$column = "resume";
				$runQuery = true;
				break;
			case "Titulo":
				$column = "title";
				$runQuery = true;
				break;
			case "Prioridade":
				$column = "id_priority";
				$runQuery = true;
				break;
			case "Respons�vel":
				$column = "id_responsible";
				$runQuery = true;
				break;
		}
		if($runQuery) {
			$query = "UPDATE $table SET $column = '$value' WHERE $idColumn = $id";
			if($value != "0") {
				$rs = mysql_query($query, $gtp) or die(mysql_error());
				echo $value;
			}
			else {
				echo "Valor inv�lido!";
			}
		}
// 		echo $value; 
	}
	if($table == "transactions") {
		$runQuery = false;
		switch(utf8_decode($column)) {
			case "Data":
				$column = "date";
				$value = date("Y-m-d",strtotime(str_replace("/","-",$value)));
				$runQuery = true;
				break;
			case "Transa��o":
				$column = "id_type";
				$runQuery = true;
				break;
			case "Documento":
				$column = "document";
				$runQuery = true;
				break;
			case "Tipo":
				$column = "id_expense";
				$runQuery = true;
				break;
			case "Descri��o":
				$column = "description";
				$runQuery = true;
				break;
			case "Valor":
				$column = "value";
				$value = abs(fixnumberUS($value));
				$runQuery = true;
				break;
		}
		if($runQuery) {
			$query = "UPDATE $table SET $column = '$value' WHERE $idColumn = $id";
			if($value != "0" && $id > 0) {
				$rs = mysql_query($query, $gtp) or die(mysql_error());
				$value = _any('value');
				echo $value;
			}
			else {
				if($id == -1)
					echo utf8_encode("N�o pode editar lan�amentos projetados! Modificar via p�gina de projetos ou usu�rios.");
				else
					echo utf8_encode("Valor inv�lido!");
			}
		}
		// 		echo $value;
	}
	
	else {
		$dao[$table]->update(array($column => $value), "$idColumn = $id");
		echo $value;
	}
// 	echo "<br>$query<br>";
// 	print_r($_POST);
}
?>