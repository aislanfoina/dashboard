                <div class="col-lg-10">
                    <h2>Página do Advogado</h2>
                </div>
                
            </div>
        <div class="wrapper wrapper-content">
            <div class="row animated fadeInRight">
                 <div class="col-md-4">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Caixa de Mensagens</h5>
                        </div>
                        <div>
                            <div class="ibox-content  ">
                                <small>Você tem 42 mensagens e 6 notificações.</small>
                                <ul class="list-group clear-list m-t">
                                <li class="list-group-item fist-item">
                                        <span class="pull-right">
                                            09:00 pm
                                        </span>
                                <span class="label label-success">1</span> Por favor, entre em contato
                                </li>
                                <li class="list-group-item">
                                    <span class="pull-right">
                                        10:16 am
                                    </span>
                                    <span class="label label-info">2</span> Assine o contrato
                                </li>
                                <li class="list-group-item">
                                    <span class="pull-right">
                                        08:22 pm
                                    </span>
                                    <span class="label label-primary">3</span> Protocole o prazo
                                </li>
                                <li class="list-group-item">
                                    <span class="pull-right">
                                        11:06 pm
                                    </span>
                                    <span class="label label-default">4</span> Retorne ao cliente
                                </li>
                                <li class="list-group-item">
                                    <span class="pull-right">
                                        12:00 am
                                    </span>
                                    <span class="label label-primary">5</span> Compareça à reunião
                                </li>
                                </ul>
                            </div>
                       
                            <div class="ibox-content profile-content">
                                <h4><strong>Avaliação</strong></h4>
                                <div>
                                    <canvas id="radarChart" height="250"></canvas>
                                </div>  
                                                                
                                <div class="row m-t-lg">
                                    <div class="col-md-4">
                                        <span class="bar">5,3,9,6,5,9,7,3,5,2</span>
                                        <h5><strong>142</strong> Avaliações</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <span class="line">5,3,9,6,5,9,7,3,5,2</span>
                                        <h5><strong>22</strong> Clientes</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <span class="bar">5,3,2,-1,-3,-2,2,3,5,2</span>
                                        <h5><strong>240</strong> Atendimentos</h5>
                                    </div>
                                </div>
                                
                            </div>
                    </div>
                </div>
                    </div>
               
                
                
          
          
                 <div class="col-lg-8">
                    <div class="ibox">
                        <div class="ibox-title">
                            <h5>Lista de Prazos</h5>
                            <div class="ibox-tools">
                                <a href="#" class="btn btn-primary btn-xs">Novo</a>
                            </div>
                        </div>
                        <div class="ibox-content">

                            <div class="m-b-lg">

                                <div class="input-group">
                                    <input type="text" placeholder="Escreva aqui sua pesquisa..." class=" form-control">
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-white"> Pesquisar</button>
                                    </span>
                                </div>
                                <div class="m-t-md">

                                    <div class="pull-right">
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-list"></i> </button>
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-pencil"></i> </button>
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-print"></i> </button>
                                        <button type="button" class="btn btn-sm btn-white"> <i class="fa fa-cogs"></i> </button>
                                    </div>

                                    <strong>Encontrados 8 prazos.</strong>



                                </div>

                            </div>

                            <div class="table-responsive">
                            <table class="table table-hover issue-tracker">
                                <tbody>
                                <tr>
                                    <td>
                                        <span class="label label-primary">Cumprido</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial da cliente Sra. Maria da Silva.
                                        </small>
                                    </td>
                                    <td>
                                        Henrique Arake
                                    </td>
                                    <td>
                                        12.02.2015 10:00 am
                                    </td>
                                    <td>
                                        <span class="pie">0.52,1.041</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-primary">Cumprido</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial da cliente Sra. Maria da Silva.
                                        </small>
                                    </td>
                                    <td>
                                        Juliana D'Ávila
                                    </td>
                                    <td>
                                        10.02.2015 05:32 am
                                    </td>
                                    <td>
                                        <span class="pie">3,2</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                                                
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-primary">Cumprido</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Apelação
                                        </a>

                                        <small>
                                            Redigir apelação do caso do Sr. Joaquim.
                                        </small>
                                    </td>
                                    <td>
                                        Anthony Jackson
                                    </td>
                                    <td>
                                        02.03.2015 06:02 am
                                    </td>
                                    <td>
                                        <span class="pie">1,2</span>
                                        1d
                                    </td>
                                    <td class="text-right">
                                                               
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-warning">Pendente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial do Sr. Pedro.
                                        </small>
                                    </td>
                                    <td>
                                        Alex Ferguson
                                    </td>
                                    <td>
                                        28.11.2015 05:10 pm
                                    </td>
                                    <td>
                                        <span class="pie">1,2</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-white btn-xs"> Concluir</button>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-warning">Pendente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Tarefa
                                        </a>

                                        <small>
                                            Agendar reunião com cliente para discussão dos detalhes do processo.
                                        </small>
                                    </td>
                                    <td>
                                        Mark Conor
                                    </td>
                                    <td>
                                        18.09.2015 06:20 pm
                                    </td>
                                    <td>
                                        <span class="pie">3,2</span>
                                        3d
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-white btn-xs"> Concluir</button>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-warning">Pendente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Feedback
                                        </a>

                                        <small>
                                            Responder aos questionamentos do coordenador
                                        </small>
                                    </td>
                                    <td>
                                        Anna Johnson
                                    </td>
                                    <td>
                                        13.05.2014 09:20 pm
                                    </td>
                                    <td>
                                        <span class="pie">2,7</span>
                                        3d
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-white btn-xs"> Concluir</button>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-danger">Urgente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                            Inicial
                                        </a>

                                        <small>
                                            Redigir inicial do Sr. Marcelo.
                                        </small>
                                    </td>
                                    <td>
                                        Henrique Arake
                                    </td>
                                    <td>
                                        12.02.2015 10:00 am
                                    </td>
                                    <td>
                                        <span class="pie">0.52,1.041</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                       <button class="btn btn-white btn-xs"> Concluir</button>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="label label-danger">Urgente</span>
                                    </td>
                                    <td class="issue-info">
                                        <a href="process_detail.php?id=1">
                                           Feedback
                                        </a>

                                        <small>
                                            Responder questionamento do cliente sobre processo.
                                        </small>
                                    </td>
                                    <td>
                                        Anna Smith
                                    </td>
                                    <td>
                                        10.02.2015 05:32 am
                                    </td>
                                    <td>
                                        <span class="pie">3,2</span>
                                        2d
                                    </td>
                                    <td class="text-right">
                                       <button class="btn btn-white btn-xs"> Concluir</button>
                                        
                                    </td>
                                </tr>
                                
                                </tbody>
                            </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
      <script>
        $(document).ready(function() {

            var radarData = {
        labels: ["Qualidade", "Disponibilidade", "Assiduidade", "Pontualidade", "Celeridade", "Estabelecimento", "Afinidade"],
        datasets: [
            {
                label: "My First dataset",
                fillColor: "rgba(220,220,220,0.2)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [65, 59, 90, 81, 56, 55, 40]
            },
            {
                label: "My Second dataset",
                fillColor: "rgba(26,179,148,0.2)",
                strokeColor: "rgba(26,179,148,1)",
                pointColor: "rgba(26,179,148,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [28, 48, 40, 19, 96, 27, 100]
            }
        ]
    };

    var radarOptions = {
        scaleShowLine: true,
        angleShowLineOut: true,
        scaleShowLabels: false,
        scaleBeginAtZero: true,
        angleLineColor: "rgba(0,0,0,.1)",
        angleLineWidth: 1,
        pointLabelFontFamily: "'Arial'",
        pointLabelFontStyle: "normal",
        pointLabelFontSize: 10,
        pointLabelFontColor: "#666",
        pointDot: true,
        pointDotRadius: 3,
        pointDotStrokeWidth: 1,
        pointHitDetectionRadius: 20,
        datasetStroke: true,
        datasetStrokeWidth: 2,
        datasetFill: true,
        responsive: true,
    }

    var ctx = document.getElementById("radarChart").getContext("2d");
    var myNewChart = new Chart(ctx).Radar(radarData, radarOptions);
 
            
            
        });
    </script>
            