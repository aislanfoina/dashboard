<?php require("../common/config.php")?>
<?php 
$aliases = $dao['mailaliases']->getAliases();
$domains = $dao['maildomains']->getDomains();
$users = $dao['mailusers']->getUsers();
?>
<!DOCTYPE html>
<html>
<head>
<?php include("part_head.php");?>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
<?php include("part_sidebar.php");?>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
<?php include("part_topbar.php");?>   
        
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Mail DB</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="main.php">Home</a>
                        </li>
                        <li class="active">
                            <strong>MailDB</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>MailDB</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                    	<h2>Aliases</h2>
                    	<div class="add_delete_toolbar" />
			 			<table class="table table-striped table-bordered table-hover" id="alias">
				            <thead>
					            <tr>
					                <th>mail</th>
					                <th>destination</th>
					                <th>enabled</th>
					            </tr>
				            </thead>
				            <tbody>
<?php foreach ($aliases as $alias) { ?>
<?php 	
	$prefix = "mailaliases";
	$idColumn = "pkid";
	$id = $alias['pkid'];
	$name = $alias['mail'];
	$dest = $alias['destination'];
	$status = $alias['enabled'];

	$this_page = $_SERVER['PHP_SELF'];
	
	$img_src = "images/ico-excluir.jpg";
	$img_alt = "Deletar";
	$img_class = "img_del";
	$img_link = "$this_page?id=".$id."&action=delAlias";
?>
					            <tr id="<?php echo "$idColumn|$id"?>">
					                <td> <?php echo $name?></td>
					                <td><?php echo $dest?></td>
					                <td><?php echo $status?></td>
					            </tr>
<?php } ?>	            
				            </tbody>
				        </table>

                    	<h2>Mailboxes</h2>
                    	<div class="add_delete_toolbar" />
<!-- 						<a onclick="fnClickAddRow();" href="javascript:void(0);" class="btn btn-primary ">Add a new row</a>-->
			 			<table class="table table-striped table-bordered table-hover" id="mailbox">
				            <thead>
					            <tr>
					                <th>name</th>
					                <th>maildir</th>
					                <th>crypt</th>
					                <th>quota</th>
					                <th>enabled</th>
					            </tr>
				            </thead>
				            <tbody>
<?php foreach($users as $user) { ?>
<?php 	
	$prefix = "mailusers";
	$idColumn = "id";
	$id = $user['id'];
	$name = $user['name'];
	$folder = $user['maildir'];
	$pass = $user['crypt'];
	$quota = $user['quota'];
	$status = $user['enabled'];
	
	$this_page = $_SERVER['PHP_SELF'];
	
	$img_src = "images/ico-excluir.jpg";
	$img_alt = "Deletar";
	$img_class = "img_del";
	$img_link = "$this_page?id=".$id."&action=delUser";
?>
					            <tr id="<?php echo "$idColumn|$id"?>">
					                <td><?php echo $id?></td>
					                <td><?php echo $name?></td>
								    <td><?php echo $folder?></td>
					                <td><?php echo $pass?></td>
					                <td><?php echo $status?></td>
					            </tr>
<?php } ?>	            
				            </tbody>
				        </table>

                    	<h2>Domains</h2>
                    	<div class="add_delete_toolbar" />
                    	
<!--                     	<button id="btnAddNewRow">Add</button> -->
<!--                     	<button id="btnDeleteRow">Del</button> -->
<!-- <form id="formAddNewRow" action="#" title="Add new company"> -->
<!--     <label for="name">Name</label><input type="text" name="name" id="name" class="required" rel="0" /> -->
<!--     <br /> -->
<!--     <label for="name">Address</label><input type="text" name="address" id="address" rel="1" /> -->
<!--     <br /> -->
<!--     <label for="name">Postcode</label><input type="text" name="postcode" id="postcode"/> -->
<!--     <br /> -->
<!--     <label for="name">Town</label><input type="text" name="town" id="town" rel="2" /> -->
<!--     <br /> -->
<!--     <label for="name">Country</label><select name="country" id="country"> -->
<!--                                         <option value="1">Serbia</option> -->
<!--                                         <option value="2">France</option> -->
<!--                                         <option value="3">Italy</option> -->
<!--                                         </select>    -->
<!--     <br />          -->
<!-- </form> -->
			 			<table class="table table-striped table-bordered table-hover" id="domain">
				            <thead>
					            <tr>
					                <th>domain</th>
					                <th>enabled</th>
					            </tr>
				            </thead>
				            <tbody>
<?php foreach($domains as $domain) { ?>
<?php 	
	$prefix = "maildomains";
	$idColumn = "pkid";
	$id = $domain['pkid'];
	$name = $domain['domain'];
	$status = $domain['enabled'];
	
	$this_page = $_SERVER['PHP_SELF'];
	
	$img_src = "images/ico-excluir.jpg";
	$img_alt = "Deletar";
	$img_class = "img_del";
	$img_link = "$this_page?id=".$id."&action=delDomain";
?>
					            <tr id="<?php echo "$idColumn|$id"?>">
					                <td><?php echo $name?></td>
					                <td><?php echo $status?></td>
					            </tr>
<?php } ?>	            
				            </tbody>
				        </table>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
            <div class="footer">
<?php include("part_footer.php")?>
            </div>
        </div>
    </div>
</body>
<?php include("part_scripts.php")?>
<script>
var editor_domain;
var editor_alias;
var editor_mailbox;
$(document).ready(function() {

     
     editor_alias = new $.fn.dataTable.Editor( {
    	ajax: "tool_ajax_datatables_editor.php",
     	table: "#alias",
     	fields: [ {
	            label: "Mail:",
	            name: "mailaliases.mail"
		    }, {
        	    label: "Destination:",
            	name: "mailaliases.destination"
	        }, {
	            label: "Status:",
	            name: "mailaliases.enabled"
	        }
	    ]
     });
     // Activate an inline edit on click of a table cell
//      $('#alias').on( 'click', 'tbody td', function (e) {
//     	 editor_domain.inline( this );
//      } );
     $('#alias').DataTable( {
 		"bPaginate": false,
 	    "oLanguage": {
 	    	"sLengthMenu": "Display _MENU_ records per page",
 	        "sZeroRecords": "Nada encontrado - desculpe",
 	        "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
 	        "sInfoEmpty": "Mostrando de 0 até 0 de 0 registros",
 	        "sInfoFiltered": "(filtrado de _MAX_ registos totais)",
 	        "sSearch": "Buscar: "
 		},
 		dom: 'Bfrtip',
    	select: true,
    	buttons: [
    		{ extend: 'create', editor: editor_alias },
			{ extend: 'edit',   editor: editor_alias },
			{ extend: 'remove', editor: editor_alias }
		],
  		columns: [
   	    	{ data: 'mailaliases.mail' },
   	    	{ data: 'mailaliases.destination' },
   	        { data: 'mailaliases.enabled' }
		]
     });

     
     editor_mailbox = new $.fn.dataTable.Editor( {
    	ajax: "tool_ajax_datatables_editor.php",
     	table: "#mailbox",
     	fields: [ {
	            label: "ID:",
	            name: "mailusers.id"
	        }, {
	            label: "Name:",
	            name: "mailusers.name"
	        }, {
	            label: "Maildir:",
	            name: "mailusers.maildir"
	        }, {
	            label: "Crypt:",
	            name: "mailusers.crypt"
	        }, {
	            label: "Status:",
	            name: "mailusers.enabled"
	        }
	    ]
     });
     // Activate an inline edit on click of a table cell
//      $('#mailbox').on( 'click', 'tbody td', function (e) {
//     	 editor_mailbox.inline( this );
//      } );
     $('#mailbox').DataTable( {
 		"bPaginate": false,
 	    "oLanguage": {
 	    	"sLengthMenu": "Display _MENU_ records per page",
 	        "sZeroRecords": "Nada encontrado - desculpe",
 	        "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
 	        "sInfoEmpty": "Mostrando de 0 até 0 de 0 registros",
 	        "sInfoFiltered": "(filtrado de _MAX_ registos totais)",
 	        "sSearch": "Buscar: "
 		},
 		dom: 'Bfrtip',
    	select: true,
    	buttons: [
    		{ extend: 'create', editor: editor_mailbox },
			{ extend: 'edit',   editor: editor_mailbox },
			{ extend: 'remove', editor: editor_mailbox }
		],
  		columns: [
   	    	{ data: 'mailusers.id' },
   	    	{ data: 'mailusers.name' },
   	    	{ data: 'mailusers.maildir' },
   	    	{ data: 'mailusers.crypt' },
   	        { data: 'mailusers.enabled' }
		]
     });

	 editor_domain = new $.fn.dataTable.Editor( {
    	ajax: "tool_ajax_datatables_editor.php",
     	table: "#domain",
     	fields: [ {
	            label: "Domain:",
	            name: "maildomains.domain"
	        }, {
	            label: "Status:",
	            name: "maildomains.enabled"
	        }
	    ]
     });
     // Activate an inline edit on click of a table cell
//      $('#domain').on( 'click', 'tbody td', function (e) {
//     	 editor_domain.inline( this );
//      } );
     $('#domain').DataTable( {
 		"bPaginate": false,
 	    "oLanguage": {
 	    	"sLengthMenu": "Display _MENU_ records per page",
 	        "sZeroRecords": "Nada encontrado - desculpe",
 	        "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
 	        "sInfoEmpty": "Mostrando de 0 até 0 de 0 registros",
 	        "sInfoFiltered": "(filtrado de _MAX_ registos totais)",
 	        "sSearch": "Buscar: "
 		},
 		dom: 'Bfrtip',
    	select: true,
    	buttons: [
    		{ extend: 'create', editor: editor_domain },
			{ extend: 'edit',   editor: editor_domain },
			{ extend: 'remove', editor: editor_domain }
		],
  		columns: [
   	    	{ data: 'maildomains.domain' },
   	        { data: 'maildomains.enabled' }
		]
     });
     
/*
    $('.datatable-edit-old').dataTable({
    	"bPaginate": false,
    	dom: '<"html5buttons"B>lTfgitp',
	    buttons: [
		     { extend: 'copy'},
		     {extend: 'csv'},
		     {extend: 'excel', title: 'Excel'},
		     {extend: 'pdf', title: 'PDF'},
		
		     {extend: 'print',
		      customize: function (win){
		             $(win.document.body).addClass('white-bg');
		             $(win.document.body).css('font-size', '10px');
		
		             $(win.document.body).find('table')
		                     .addClass('compact')
		                     .css('font-size', 'inherit');
		     }
		     }
		],
        "oLanguage": {
        	"sLengthMenu": "Display _MENU_ records per page",
            "sZeroRecords": "Nada encontrado - desculpe",
            "sInfo": "Mostrando de _START_ at� _END_ de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando de 0 at� 0 de 0 registros",
            "sInfoFiltered": "(filtrado de _MAX_ registos totais)",
            "sSearch": "Buscar: "
		}
    }).makeEditable({
		sUpdateURL: 'tool_ajax_datatables_general.php',
		sAddURL: 'tool_ajax_datatables_general.php'
    });
*/
});

</script>
</html>
