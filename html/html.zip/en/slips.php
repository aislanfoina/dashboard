<?php require("../common/config.php")?>
<?php 
$slips = $dao['slips']->getSlips();
$title = "Boletos";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<title>Intranet GTP - <?php echo $title?></title>
<link href="css.css" rel="stylesheet" type="text/css" />
<?php include("scripts.php")?>
</head>

<body id="cadastro_clientes">
<div class="main">
<?php include("part_header.php");?> 
   <div class="colA">
    	<h2>Cadastro de <?php echo $title?></h2>
<?php if(!_any('hide')) { ?>		
    	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="dataTable_1">
            <thead>
            	<tr>
            		<td colspan="8">Slips</td>
            	</tr>
	            <tr>
	                <td>customer</td>
	                <td>our_number</td>
	                <td>value</td>
	                <td>issue_date</td>
	                <td>expiration_date</td>
					<td>id_status</td>
					<td>status</td>
					<td>&nbsp;</td>
	            </tr>
            </thead>
            <tbody>
<?php 
foreach($slips as $slip) {
	$prefix = "slips";
	$idColumn = "id";
	$id = $slip['id'];
	$customer = $slip['customer'];
	$our_number = $slip['our_number'];
	$value = $slip['value'];
	$issue_date = $slip['issue_date'];
	$expiration_date = $slip['expiration_date'];
	$idStatus = $slip['id_status'];
	$status = $slip['status'];
	
	$this_page = $_SERVER['PHP_SELF'];
	
	$img_src = "images/ico-excluir.jpg";
	$img_alt = "Deletar";
	$img_class = "img_del";
	$img_link = "$this_page?id=".$id."&action=delAlias";
?>
	            <tr id="<?php echo "$prefix|$idColumn|$id"?>">
	                <td><?php echo $customer?></td>
	                <td><a href="slipView.php?slip_ournumber=<?php echo $our_number?>"><?php echo $our_number?></a></td>
	                <td><?php echo $value?></td>
	                <td><?php echo $issue_date?></td>
	                <td><?php echo $expiration_date?></td>
	                <td><?php echo $idStatus?></td>
	                <td><?php echo $status?></td>
	                <td><input name="img" type="image" class="<?php echo $img_class?>" src="<?php echo $img_src?>" value="<?php echo $img_link?>" alt="<?php echo $img_alt?>"/></td>
	            </tr>
<?php } ?>	            
            </tbody>
        </table>
<?php } ?>     
    </div>
    <div class="colB">
<?php include("part_sidemenu.php");?>
    </div>
    <div class="clear"></div>
</div>
<?php include("part_footer.php");?>
</body>
</html>
