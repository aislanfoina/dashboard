<?php
/* Copyright (C) 2015 Foi.tech - All Rights Reserved
 * You may use, distribute and modify this code under the terms of
 * the FMS license, which unfortunately won't be written for another
 * century.
 *
 * You should have received a copy of the FMS license with
 * this file. If not, please write to: license@foi.tech, or
 * visit : http://foi.tech/license.pdf
 */

class Metrics extends Crud{
	public $creation = "CREATE TABLE `metrics` (
							`id` int(9) unsigned NOT NULL AUTO_INCREMENT,
							`name` varchar(50) NOT NULL DEFAULT 'undef',
							`desc` text,
							`unit` varchar(20) NOT NULL DEFAULT 'undef',
							`value` varchar(10) NOT NULL DEFAULT 'undef',
							`ideal_value` varchar(10) NOT NULL DEFAULT 'undef',
							`tendency` varchar(10) NOT NULL DEFAULT 'undef',
							`score_formula` varchar(10) NOT NULL DEFAULT 'undef',
                            `id_status` int(3) unsigned DEFAULT 0,
							`creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
							PRIMARY KEY (`id`),
							KEY `id` (`id`)
						)";
	
	public $fields = array("metrics.id", "metrics.name", "metrics.unit", "metrics.value",      
						"status.status");
	public $join = "LEFT JOIN status ON metrics.id_status = status.id";

	public function __construct($cred){
		parent::__construct($cred);
		$this->table = "metrics";
		if(!$this->checkTable()) {
		    $data['name'] = "flights_this_week";
		    $data['value'] = "0";
		    $this->insert($data);
		    $data['name'] = "flights_last_week";
		    $data['value'] = "2";
		    $this->insert($data);
		    $data['name'] = "last_crash";
		    $data['value'] = "2018-02-15";
		    $this->insert($data);
		    $data['name'] = "system_score";
		    $data['value'] = "0.123";
		    $this->insert($data);
		}
	}

	public function getMetricbyName($name) {
	    $where = "metrics.name LIKE '$name'";
	    $ret = $this->read($this->fields,$where,null,null,null,$this->join);
	    if(count($ret)>0)
	        return $ret[0];
	    else
	        return false;
	}

	public function getMetricValuebyName($name) {
	    $where = "metrics.name LIKE '$name'";
	    $ret = $this->read($this->fields,$where,null,null,null,$this->join);
	    if(count($ret)>0) {
            $row = $ret[0];
            return $row['value'];
	    }
        else
            return false;
	}
	
	public function getMetrics($where = null, $order = null) {
		return $this->read($this->fields,$where,null,null,$order,$this->join);
	}
}
?>